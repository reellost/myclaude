package util;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.cokutau.common.utils.KuFileUtil;

public class LogUtil {

    public static final int DEBUG = 0;

    public static final int INFO = 1;

    public static final int WARN = 2;

    public static final int ERROR = 3;

	private static final String[] LOG_LEVELS = {"DEBUG", "INFO", "WARN", "ERROR"};

	private static String logFileName = null;

	public static boolean saveToLocal = true;

	private static final SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	public static void setLogFile(String filepath){
		record("log file name:" + filepath);
		logFileName = filepath;
	}

	public static void record(String str){
		record(str, 1);
	}

	public static void record(String str, int depth){
		record(str, depth + 1, INFO);
	}

	public static void recordErr(String str){
		record(str, 1, ERROR);
	}

	public static void recordErr(String str, int depth){
		record(str, depth + 1, ERROR);
	}

	public static void record(String str, int depth, int logLevel){
		depth += 1;
		String simpleStr = String.format("[%s] <%s> %s", formatter.format(new Date()), LOG_LEVELS[logLevel], str);
		if(logLevel < ERROR){
			System.out.println(simpleStr);
		}else{
			System.err.println(simpleStr);
		}

		if(saveToLocal){
			String className = new Exception().getStackTrace()[depth].getClassName(); //获取调用者的类名
			String methodName = new Exception().getStackTrace()[depth].getMethodName(); //获取调用者的方法名
			String recordStr = String.format("[%s] <%s> [%s]%s: %s\n", formatter.format(new Date()), LOG_LEVELS[logLevel], className, methodName, str);

			try {
				saveToFile(recordStr);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	private static void saveToFile(String str) throws IOException{
		if(logFileName == null || logFileName.isEmpty()){
//			System.out.println("save log file failed: file not exist:" + logFileName);
			return;
		}

		File file = new File(logFileName);

		if(!file.exists()){
			file.createNewFile();
		}

		if(file.exists()){
			KuFileUtil.writeStringToFile(file, str, "utf-8", true);
		}else{
			System.out.println("save log file failed: create file failed");
		}
	}
}
