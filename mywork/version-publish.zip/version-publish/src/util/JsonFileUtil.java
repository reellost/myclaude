package util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

public class JsonFileUtil {

	public static String getStr(String filePath) throws IOException{
		BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(filePath)));
		String result = "";
		for (String line = br.readLine(); line != null; line = br.readLine()) {
			result = result.concat(line).concat("\n");
        }
		br.close();
		return result;
	}

	public static String getStr(InputStream inputStream) throws IOException{
		byte[] b = new byte[1024];
		int l = 0;
		String result = "";
		while ((l = inputStream.read(b)) != -1) {
			result += new String(b, 0, l, "UTF-8");
		}
		return result;
	}

	public static Object readJson(String filePath,Class<?> classT){
		Object obj = null;
		try {
			if(new File(filePath).exists()){
				String txt = getStr(filePath);
				obj = JSON.parseObject(txt,classT);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return obj;
	}

	public static JSONObject readJsonHashMap(String filePath){
		JSONObject obj = null;
		try {
			if(new File(filePath).exists()){
				String txt = getStr(filePath);
				obj = JSON.parseObject(txt);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return obj;
	}

	public static JSONObject readJsonHashMap(InputStream inputStream){
		JSONObject obj = null;
		try {
			String txt = getStr(inputStream);
			obj = JSON.parseObject(txt);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return obj;
	}

	public static void writJson(String filePath, Object obj){
		try {
			File file = new File(filePath);
			if(!file.exists()){
				file.createNewFile();
			}else{
				file.delete();
				file.createNewFile();
			}
			FileWriter fileWritter = new FileWriter(filePath,true);
            BufferedWriter bufferWritter = new BufferedWriter(fileWritter);

            String data = JSON.toJSONString(obj,true);
            bufferWritter.write(data);
            bufferWritter.flush();
            bufferWritter.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
