package util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.UnknownHostException;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;

import model.event.CommonEvent;
import model.event.OutputManager;

public class HttpUtil {

	private static void notifyEvent(String msg) {
		OutputManager.getInstance().notifyEvent(CommonEvent.EventType.OUT_MSG, msg + "\n");
		LogUtil.record(msg);
	}

	private static void notifyError(String msg){
		OutputManager.getInstance().notifyEvent(CommonEvent.EventType.OUT_MSG, msg + "\n");
		LogUtil.recordErr(msg);
	}

	public static boolean postHttp(String url, Map<String, String> params){
		if(!url.toLowerCase().contains("http://")){
			url = "http://" + url;
		}
		CloseableHttpClient httpclient = HttpClients.createDefault();
		MultipartEntityBuilder builder = MultipartEntityBuilder.create();
		for (Entry<String, String> e : params.entrySet()) {
			builder.addTextBody(e.getKey(), e.getValue());
		}
		HttpPost httpPost = new HttpPost(url);
		httpPost.setEntity(builder.build());
		try{
			notifyEvent(String.format("httpPost: %s", url));
			HttpResponse response = httpclient.execute(httpPost);
			notifyEvent("response status code: "+ response.getStatusLine().getStatusCode());
			if (response.getStatusLine().getStatusCode() != 200){
				return false;
			}
			httpclient.close();
		}catch (IOException e) {
			notifyError(String.format("操作出错(IOException):%s", e.getMessage()));
			return false;
		}
		return true;
	}

	public static boolean downloadFile(String url, String desFileName){
		if(!url.toLowerCase().startsWith("http")){
			url = "http://" + url;
		}
		CloseableHttpClient httpclient = HttpClients.createDefault();
		HttpGet httpget = new HttpGet(url);
		try {
			notifyEvent(String.format("start get file from url: %s", url));
			HttpResponse response = httpclient.execute(httpget);
			HttpEntity entity = response.getEntity();
			notifyEvent("response status code: "+ response.getStatusLine().getStatusCode());
			if (response.getStatusLine().getStatusCode() != 200){
				notifyEvent("下载失败");
				return false;
			}
			saveHttpEntity(entity, desFileName);
			httpclient.close();
		}catch(UnknownHostException e){
			notifyError(String.format("操作出错(UnknownHostException): %s", e.getMessage()));
		} catch (IOException e) {
			notifyError(String.format("操作出错(IOException): %s", e.getMessage()));
			return false;
		}
		return true;
	}

	public static void saveHttpEntity(HttpEntity entity, String filepath){
		notifyEvent(String.format("start save info to file: %s", filepath));
		File file = new File(filepath);
		if (!file.exists()) {
			try {
				file.createNewFile();
				OutputStream outputStream = new FileOutputStream(file);
				entity.writeTo(outputStream);
				outputStream.flush();
				outputStream.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				notifyError(String.format("操作出错(IOException) %s", e.getMessage()));
			}
		}
	}
}
