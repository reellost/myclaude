package util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.commons.codec.digest.DigestUtils;

public class CompareUtil {
	
	public static String compareTwoFiles(String pathA, String pathB){
		// 先判断文件大小是否一致，
		long sizeA = getFileSize(pathA);
		long sizeB = getFileSize(pathB);
		if(sizeA != sizeB) {
			return String.valueOf(sizeA);
		}
		
		// 如果大小相同再比较MD5
		String md5A = getMD5Checksum(pathA);
		String md5B = getMD5Checksum(pathB);
		if(!md5A.equals(md5B))
		{
			return md5A;
		}
		else
		{
			return null;
		}
	}
	
	public static long getFileSize(String filename) {
		File file = new File(filename);
		if(file.exists() && file.isFile()) {
			return file.length();
		}
		return 0;
	}
	
	public static String getMD5Checksum(String filename) {  
		File file = new File(filename);
		if(!file.exists())
		{
			return null;
		}
		String md5 = "";
		try {
			md5 = DigestUtils.md5Hex(new FileInputStream(file));
		} catch (IOException e) {
			e.printStackTrace();
		}
		return md5;
	}
	
	public static String getMD5Checksum(File file){
		if(!file.exists())
		{
			return null;
		}
		String md5 = "";
		try {
			md5 = DigestUtils.md5Hex(new FileInputStream(file));
		} catch (IOException e) {
			e.printStackTrace();
		}
		return md5;
	}
}
