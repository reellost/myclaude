package application;
	
import java.util.List;

import config.VersionPublishHelper;
import javafx.application.Application;
import javafx.stage.Stage;
import ui.MainPanel;
import ui.SettingPanel;

public class Main extends Application {
	private Stage stage;
	
	@Override
	public void start(Stage primaryStage) {
		stage = primaryStage;
		
		Parameters p = this.getParameters();
		List<String> unnamedParams = p.getUnnamed();
		init(unnamedParams.size() > 0 ? unnamedParams.get(0) : "");
	}
	
	private void init(String relativePath) {
		boolean ret = VersionPublishHelper.init(relativePath);
		if(ret) {
			showMainPanel();
		}else {
			showSetupPanel();
		}
	}
	
	public void showSetupPanel(){
		new SettingPanel(stage,()->{
			showMainPanel();
		}).show();
	}
	
	public void showMainPanel(){
		VersionPublishHelper.envNew();
		
		new MainPanel(stage).show();
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
