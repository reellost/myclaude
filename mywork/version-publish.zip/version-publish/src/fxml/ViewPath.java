package fxml;

public class ViewPath {

}
