
import gzip
import shutil
import sys
import os
import re
import tempfile
import struct 
from multiprocessing import Pool

_DELTA = 0x9E3779B9

JS = re.compile(r'\.js$')

def _long2str(v, w):  
    n = (len(v) - 1) << 2  
    if w:  
        m = v[-1]  
        if (m < n - 3) or (m > n): return ''  
        n = m  
    s = struct.pack('<%iL' % len(v), *v)  
    return s[0:n] if w else s  

def _str2long(s, w):  
    n = len(s)  
    m = (4 - (n & 3) & 3) + n  
    s = s.ljust(m, "\0")  
    v = list(struct.unpack('<%iL' % (m >> 2), s))  
    if w: v.append(n)  
    return v  

def encrypt(str, key):  
    if str == '': return str  
    v = _str2long(str, True)  
    k = _str2long(key.ljust(16, "\0"), False)  
    n = len(v) - 1  
    z = v[n]  
    y = v[0]  
    sum = 0  
    q = 6 + 52 // (n + 1)  
    while q > 0:  
        sum = (sum + _DELTA) & 0xffffffff  
        e = sum >> 2 & 3  
        for p in xrange(n):  
            y = v[p + 1]  
            v[p] = (v[p] + ((z >> 5 ^ y << 2) + (y >> 3 ^ z << 4) ^ (sum ^ y) + (k[p & 3 ^ e] ^ z))) & 0xffffffff  
            z = v[p]  
        y = v[0]  
        v[n] = (v[n] + ((z >> 5 ^ y << 2) + (y >> 3 ^ z << 4) ^ (sum ^ y) + (k[n & 3 ^ e] ^ z))) & 0xffffffff  
        z = v[n]  
        q -= 1  
    return _long2str(v, False)

def isGzipFile(filename):
    try:
        with open(filename, 'rb') as f:
            magic_number = f.read(2)
            return magic_number == b'\x1f\x8b'
    except IOError:
        return False

def gzipCompress(file):
    with open(file, 'rb') as original_file:
        compressed_content = original_file.read()
        with gzip.open(file+".gz", 'wb') as compressed_file:
            compressed_file.write(compressed_content)

def readBytesData(file):
    bytesFile = open(file, "rb")
    return bytesFile.read()

def writeBytesData(file, data):
    file = open(file, "wb")
    file.write(data)
    file.close()
    print("write file:{0}".format(file))

def compressAndEncrypt(dir, encryptkey):
    gzipCompress(dir)
    # gizpData = readBytesData(dir+".gz");
    # jscData = encrypt(gizpData, encryptkey)
    # writeBytesData(dir+"c", jscData)
    # os.remove(dir+".gz")
    # print("compress and encrypt sucess:"+dir+"c")
    if os.path.exists(dir+".gz"):
        os.remove(dir)
        os.rename(dir+".gz", dir);
        print("gzip compress sucess:"+dir)

def findAndZipJSC(dir, encryptkey):
    rootpath = os.path.abspath(dir)
    for path in os.listdir(rootpath):
        abs_file = os.path.join(rootpath, path)
        if os.path.isdir(abs_file):
            findAndZipJSC(abs_file, encryptkey)
        elif os.path.isfile(abs_file):
            fileType = os.path.splitext(abs_file)[1]
            if JS.match(fileType):
                compressAndEncrypt(abs_file, encryptkey)

if __name__ == "__main__":
    filePath = sys.argv[1]
    encryptkey = sys.argv[2]
    findAndZipJSC(filePath, encryptkey)


