
import os
import shutil
import struct 
import time
from multiprocessing import Pool

_DELTA = 0x9E3779B9  

def _long2str(v, w):  
    n = (len(v) - 1) << 2  
    if w:  
        m = v[-1]  
        if (m < n - 3) or (m > n): return ''  
        n = m  
    s = struct.pack('<%iL' % len(v), *v)  
    return s[0:n] if w else s  
  
def _str2long(s, w):  
    n = len(s)  
    m = (4 - (n & 3) & 3) + n  
    s = s.ljust(m, "\0")  
    v = list(struct.unpack('<%iL' % (m >> 2), s))  
    if w: v.append(n)  
    return v  
  
def encrypt(str, key):  
    if str == '': return str  
    v = _str2long(str, True)  
    k = _str2long(key.ljust(16, "\0"), False)  
    n = len(v) - 1  
    z = v[n]  
    y = v[0]  
    sum = 0  
    q = 6 + 52 // (n + 1)  
    while q > 0:  
        sum = (sum + _DELTA) & 0xffffffff  
        e = sum >> 2 & 3  
        for p in xrange(n):  
            y = v[p + 1]  
            v[p] = (v[p] + ((z >> 5 ^ y << 2) + (y >> 3 ^ z << 4) ^ (sum ^ y) + (k[p & 3 ^ e] ^ z))) & 0xffffffff  
            z = v[p]  
        y = v[0]  
        v[n] = (v[n] + ((z >> 5 ^ y << 2) + (y >> 3 ^ z << 4) ^ (sum ^ y) + (k[n & 3 ^ e] ^ z))) & 0xffffffff  
        z = v[n]  
        q -= 1  
    return _long2str(v, False)  
  
def decrypt(str, key):  
    if str == '': return str  
    v = _str2long(str, False)  
    k = _str2long(key.ljust(16, "\0"), False)  
    n = len(v) - 1  
    z = v[n]  
    y = v[0]  
    q = 6 + 52 // (n + 1)  
    sum = (q * _DELTA) & 0xffffffff  
    while (sum != 0):  
        e = sum >> 2 & 3  
        for p in xrange(n, 0, -1):  
            z = v[p - 1]  
            v[p] = (v[p] - ((z >> 5 ^ y << 2) + (y >> 3 ^ z << 4) ^ (sum ^ y) + (k[p & 3 ^ e] ^ z))) & 0xffffffff  
            y = v[p]  
        z = v[n]  
        v[0] = (v[0] - ((z >> 5 ^ y << 2) + (y >> 3 ^ z << 4) ^ (sum ^ y) + (k[0 & 3 ^ e] ^ z))) & 0xffffffff  
        y = v[0]  
        sum = (sum - _DELTA) & 0xffffffff  
    return _long2str(v, True)  

def deep_iterate_dir(list, rootDir):
    for lists in os.listdir(rootDir):
        path = os.path.join(rootDir, lists)
        if os.path.isdir(path):
            deep_iterate_dir(list,path)
        elif os.path.isfile(path):
            list.append(path)

def normalize_path(self, url):
    url = os.path.normpath(url)
    if not os.path.isabs(url):
        url = os.path.abspath(url)
    return url

def get_relative_path(srcUrl, luafile):
    try:
        pos = luafile.index(srcUrl)
        if pos != 0:
            print("cannot find src directory in file path.")

        return luafile[len(srcUrl)+1:]
    except ValueError:
        print("cannot find src directory in file path.")

def get_output_file_path(srcUrl, dstUrl, luafile):
    """
    Gets output file path by source file
    """
    filePath = ""
    relative_path = get_relative_path(srcUrl, luafile)
    filePath = os.path.join(dstUrl, relative_path)
    folderPath = os.path.split(filePath)[0]
    try:
        os.makedirs(folderPath)
    except OSError:
        if os.path.exists(folderPath) == False:
            print("Error: cannot create folder in " + folderPath)

    return filePath

def get_file_encript_data(file, dstFile, options):
    bytesFile = open(file, "rb")
    encryBytes = encrypt(bytesFile.read(), options.encryptkey)
    bytesFile.close()

    encryBytes = options.encryptsign + encryBytes
    return [dstFile, encryBytes]

def write_to_file(list):
    file = open(list[0], "wb")
    file.write(list[1])
    file.close()
    print("write file:{0}".format(list[0]))

def main():
    print("----------------------------------init main--------------------------------------")

    from optparse import OptionParser

    parser = OptionParser("usage:encrypt -s src_dir -d dst_dir")

    parser.add_option("-s", "--src",
                      action="store", type="string", dest="src_dir",
                      help="source directory of files needed to be encrypt")
    parser.add_option("-d", "--dst",
                      action="store", type="string", dest="dst_dir",
                      help="destination directory of encrypted files to be stored")
    parser.add_option("-k", "--encryptkey",
                      dest="encryptkey",default="Cokutau_pjzz",
                      help="encrypt key")
    parser.add_option("-b", "--encryptsign",
                      dest="encryptsign",default="Cokutau",
                      help="encrypt sign")
    parser.add_option("-e", "--extension",
                      action="append", type="string", dest="ext_arr",
                      help="file extensions of encrypted files to be stored")

    (options, args) = parser.parse_args()

    print("source %s,destination %s,encryptkey %s,encryptsign %s,extension %s" % (options.src_dir,options.dst_dir,options.encryptkey,options.encryptsign,options.ext_arr))

    if options.src_dir == None:
        print("Please set source folder by \"-s\"")
        return
    elif options.dst_dir == None:
        print("Please set destination folder by \"-d\"")
        return
    elif options.ext_arr == None:
        print("Please set file extensions by \"-e\"")
        return

    listFiles = []
    deep_iterate_dir(listFiles,options.src_dir)

    wildcardExtension = ".*"
    listFileExtensions = options.ext_arr

    print("total file count:{0}".format(len(listFiles),))
    
    start = time.time()
    p = Pool()

    for file in listFiles:
        prefix = ""
        dstFile = get_output_file_path(options.src_dir, options.dst_dir, file)
        if os.path.splitext(file)[1] in listFileExtensions or wildcardExtension in listFileExtensions:
            p.apply_async(get_file_encript_data, args=(file, dstFile, options), callback = write_to_file)

            prefix = "encrypt file"
        else:
            prefix = "copy file"
            shutil.copy(file, dstFile)

        print("{0}:{1}".format(prefix, dstFile))

    p.close()
    p.join()

    print("finish encrypt(cost:{0}s)".format(time.time() - start, ).center(34 * 2))
# main()
if __name__ == '__main__':
    main()
