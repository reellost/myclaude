package model;

import javafx.beans.property.Property;
import javafx.beans.property.SimpleStringProperty;
import config.VersionPublishHelper;
import config.VersionPublishType;

public class FileResult {
	private String orgPath;
	private String cachePath;
	private String tmpPath;
	private String gzipPath;
	private String encriptPath;
	private String md5;
	private String name;
	private String type;
	
	private String fileId;
	private String relativePath;
	
	public FileResult(String name,String type,String org,String cache){
		this.name = name;   // 文件名
		this.type = type;   // 类型： lua、res
		this.orgPath = org;  //  文件完整路径，包括文件名   示例  E:\cokutau-dev\game\ProjectC3\client\src\BattleDemoScene.lua
		this.cachePath = cache;  // 文件对应缓存目录的路径 示例 F:\ProjectC3_cache\src\BattleDemoScene.lua
		
		this.relativePath = this.orgPath.replace(VersionPublishHelper.getCustomConfigInfo().basePath + "\\", ""); // 相对路径 示例 src\BattleDemoScene.lua
		this.fileId = this.relativePath.replace("\\", "."); // 包含文件相对路径信息的唯一ID， 示例 src.BattleDemoScene.lua
//		this.tmpPath = this.orgPath.replace(AutoPublishConfig.getOrgPath(type), AutoPublishConfig.getTmpPath(type));   // 文件在临时目录中的路径
//		this.tmpPath = VersionPublishHelper.getTmpPath() + "\\" + this.fileId;
	}
	
	public void updatePath(String publishType) {
		switch(publishType) {
		case VersionPublishType.GROUP_VERSION_ZIP:
			tmpPath = orgPath.replace(VersionPublishHelper.getCustomConfigInfo().getBasePath(type), 
					VersionPublishHelper.getWorkspaceConfig().getTmpPath(type));
			gzipPath = orgPath.replace(VersionPublishHelper.getCustomConfigInfo().getBasePath(type),
					VersionPublishHelper.getWorkspaceConfig().getGZipPath() + "\\" + type);
			encriptPath = orgPath.replace(VersionPublishHelper.getCustomConfigInfo().getBasePath(type),
					VersionPublishHelper.getWorkspaceConfig().getEncriptPath() + "\\" + type);
			break;
		case VersionPublishType.GROUP_VERSION_SF:
			tmpPath = VersionPublishHelper.getWorkspaceConfig().getTmpPath() + "\\" + fileId;
			gzipPath = VersionPublishHelper.getWorkspaceConfig().getGZipPath() + "\\" + fileId;
			encriptPath = VersionPublishHelper.getWorkspaceConfig().getEncriptPath() + "\\" + fileId;
			break;
		default:
			break;
		}
	}
	
	public Property<String> getAbsloteFile(){
		Property<String> fileName = new SimpleStringProperty();
		fileName.setValue(this.orgPath);
		return fileName;
	}

	public String getTmpPath(){
		return this.tmpPath;
	}
	
	public String getOrgPath(){
		return this.orgPath;
	}
	
	public String getCachePath(){
		return this.cachePath;
	}

	public String getGzipPath(){
		return this.gzipPath;
	}

	public String getEncriptPath(){
		return this.encriptPath;
	}
	
	public String getMd5(){
		return this.md5;
	}
	
	public String getName(){
		return this.name;
	}
	
	public String getType(){
		return this.type;
	}
	
	public String getFileId() {
		return this.fileId;
	}
	
	public String getRelativePath() {
		return this.relativePath;
	}
}
