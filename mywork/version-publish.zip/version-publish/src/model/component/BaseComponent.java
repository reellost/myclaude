package model.component;

import model.event.CommonEvent;
import model.event.OutputManager;
import util.LogUtil;

public class BaseComponent {
	public void notifyEvent(String msg) {
		notifyEvent(msg, CommonEvent.EventType.INNER_MSG);
//		OutputManager.getInstance().notifyEvent(CommonEvent.EventType.INNER_MSG, msg + "\n");
	}

	protected void notifyEvent(String msg, CommonEvent.EventType eventType) {
		OutputManager.getInstance().notifyEvent(eventType, msg + "\n");
		LogUtil.record(msg, 2);
	}
}
