package model.component;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import com.cokutau.common.utils.KuFileUtil;

import config.VersionPublishHelper;
import model.CompareResult;
import model.ExecuteResult;
import model.FileResult;
import util.LogUtil;

public class PackageComponent extends BaseComponent{

	public void copyToTmpPath(ArrayList<CompareResult> compareResults){
		for (CompareResult compareResult : compareResults) {
			for(FileResult fResult : compareResult.getFileList()){
				try {
					KuFileUtil.copyFile(new File(fResult.getOrgPath()), new File(fResult.getTmpPath()));
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	/**
	 * 拷贝到temp目录，加密至encript目录
	 * @param compareResults
	 * @return
	 */
	public ExecuteResult encriptCompareResult(ArrayList<CompareResult> compareResults){
		//1.
		copyToTmpPath(compareResults);
		//2.判断是否需要进行gzip压缩
		boolean isNeedGZip = VersionPublishHelper.getCustomConfigInfo().gzip;
		if (isNeedGZip) {
			ExecuteResult result = doGZipAndJscEncode();
			if (!result.ret) {
				return result;
			}
		}

		return encript(isNeedGZip);
	}

	private ExecuteResult doGZipAndJscEncode() {
		String scriptPath = VersionPublishHelper.getCustomConfigInfo().basePath + "\\gzip_jsc.py";
		if(!KuFileUtil.isFileExist(scriptPath)) {
			scriptPath = VersionPublishHelper.getWorkspaceConfig().gzipEncriptScriptPath;
			if(!KuFileUtil.isFileExist(scriptPath)){
				return new ExecuteResult(false, "压缩失败：未发现压缩脚本：gzip_jsc.py");
			}
		}
		String sourcePath = VersionPublishHelper.getWorkspaceConfig().getTmpPath();
		String desPath = VersionPublishHelper.getWorkspaceConfig().getGZipPath();
		long start = System.currentTimeMillis();
		try {
			KuFileUtil.copyDirectory(new File(sourcePath), new File(desPath));
		} catch (IOException e) {
			e.printStackTrace();
		}
		String key = "xxxx";
		String exeStr = String.format("python %s %s %s", scriptPath, desPath, key);
		try {
			ProcessBuilder pb = new ProcessBuilder(exeStr.split(" "));
			Process process = pb.start();
			StreamGobblerThread thread4Info = new StreamGobblerThread("AdminHandler_Shell-StreamGobbler-Info", process.getInputStream(), "utf-8");
			StreamGobblerThread thread4Error = new StreamGobblerThread("AdminHandler_Shell-StreamGobbler-Error", process.getErrorStream(), "utf-8");
			thread4Info.setDaemon(true);
			thread4Error.setDaemon(true);
			thread4Info.start();
			thread4Error.start();
			if(process.waitFor() != 0) {
				return new ExecuteResult(false, "压缩失败：执行出错");
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		long now = System.currentTimeMillis();
		return new ExecuteResult(true, "压缩成功", (now - start));
	}

	private String getEncriptSourcePath(boolean isFromGzipPath) {
		if (isFromGzipPath) {
			return VersionPublishHelper.getWorkspaceConfig().getGZipPath();
		} else {
			return VersionPublishHelper.getWorkspaceConfig().getTmpPath();
		}
	}

	private ExecuteResult encript(boolean isFromGzipPath) {
		String encriptScriptPath = VersionPublishHelper.getCustomConfigInfo().basePath + "\\encript.py";
		long start = System.currentTimeMillis();
		if(!KuFileUtil.isFileExist(encriptScriptPath)) {
			encriptScriptPath = VersionPublishHelper.getWorkspaceConfig().encriptScriptPath;
			if(!KuFileUtil.isFileExist(encriptScriptPath)){
				return new ExecuteResult(false, "加密失败：未发现加密脚本");
			}
		}
		String sourcePath = getEncriptSourcePath(isFromGzipPath);
		String desPath = VersionPublishHelper.getWorkspaceConfig().getEncriptPath();
		String ext = "-e .png -e .PNG -e .jpg -e .JPG -e .proto -e .lua -e .json";
		String extraExt = VersionPublishHelper.getCustomConfigInfo().scriptExt;
		if(extraExt != null) {
			ext += " " + extraExt;
		}
		String exeStr = String.format("python %s -s %s -d %s %s", encriptScriptPath, sourcePath, desPath, ext);
		try {
			ProcessBuilder pb = new ProcessBuilder(exeStr.split(" "));
			Process process = pb.start();
			StreamGobblerThread thread4Info = new StreamGobblerThread("AdminHandler_Shell-StreamGobbler-Info", process.getInputStream(), "utf-8");
			StreamGobblerThread thread4Error = new StreamGobblerThread("AdminHandler_Shell-StreamGobbler-Error", process.getErrorStream(), "utf-8");
			thread4Info.setDaemon(true);
			thread4Error.setDaemon(true);
			thread4Info.start();
			thread4Error.start();
			if(process.waitFor() != 0) {
				return new ExecuteResult(false, "加密失败：执行出错");
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		long now = System.currentTimeMillis();
		return new ExecuteResult(true, "加密成功", (now - start));
	}

	public void stopEncript(){
		// TODO: 停止加密
	}

	public boolean packageAssets(){
		String filePath = VersionPublishHelper.getWorkspaceConfig().getEncriptPath();
		String desPath = VersionPublishHelper.getWorkspaceConfig().getZipPath();
		if(VersionPublishHelper.makeDirectory(desPath)) {
			return zipFiles(filePath, VersionPublishHelper.getWorkspaceConfig().getZipName());
		}

		return false;
	}

	public boolean packageCompareResults(ArrayList<CompareResult> compareResults, String version) {
		String zipPath = VersionPublishHelper.getWorkspaceConfig().getZipPath();
		try {
			KuFileUtil.forceMkdir(new File(zipPath));
			for(CompareResult cmpResult: compareResults) {
				String type = cmpResult.getType();
				String filePath = VersionPublishHelper.getWorkspaceConfig().getEncriptPath() + "\\" + type;
				KuFileUtil.createZip(filePath, VersionPublishHelper.getWorkspaceConfig().getZipName(type, version));
//				KuFileUtil.createZip(filePath, desPath);
			}
			notifyEvent("打包成功!");
			return true;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			LogUtil.recordErr(e.getMessage());
		}
		notifyEvent("打包失败");

		return false;
	}

	public boolean zipFiles(String srcFilePath, String tarFilePath) {
		File srcFile = new File(srcFilePath);
		File desFile = new File(tarFilePath);
		return zipFiles(srcFile, desFile);
	}
	/**
	 * 压缩文件
	 *
	 * @param srcfile
	 */
	public boolean zipFiles(File srcfile, File targetFile) {
		boolean ret = false;
		ZipOutputStream out = null;
		try {
			out = new ZipOutputStream(new FileOutputStream(targetFile));

			if(srcfile.isFile()){
				zipFile(srcfile, out, "");
			} else{
				File[] list = srcfile.listFiles();
				for (int i = 0; i < list.length; i++) {
					compress(list[i], out, "");
				}
			}

			LogUtil.record("压缩完毕: " + targetFile.getAbsolutePath());
			ret = true;
		} catch (Exception e) {
			LogUtil.record("压缩出现错误: " + srcfile.getAbsolutePath() + "  =>  " + targetFile.getAbsolutePath());
			e.printStackTrace();
		} finally {
			try {
				if (out != null)
					out.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		return ret;
	}

	/**
	 * 压缩文件夹里的文件
	 * 起初不知道是文件还是文件夹--- 统一调用该方法
	 * @param file
	 * @param out
	 * @param basedir
	 */
	private void compress(File file, ZipOutputStream out, String basedir) {
		/* 判断是目录还是文件 */
		if (file.isDirectory()) {
			this.zipDirectory(file, out, basedir);
		} else {
			this.zipFile(file, out, basedir);
		}
	}

	/**
	 * 压缩单个文件
	 *
	 * @param srcfile
	 */
	public void zipFile(File srcfile, ZipOutputStream out, String basedir) {
		if (!srcfile.exists())
			return;

		byte[] buf = new byte[1024];
		FileInputStream in = null;

		try {
			int len;
			in = new FileInputStream(srcfile);
			out.putNextEntry(new ZipEntry(basedir + srcfile.getName()));

			while ((len = in.read(buf)) > 0) {
				out.write(buf, 0, len);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (out != null)
					out.closeEntry();
				if (in != null)
					in.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * 压缩文件夹
	 * @param dir
	 * @param out
	 * @param basedir
	 */
	public void zipDirectory(File dir, ZipOutputStream out, String basedir) {
		if (!dir.exists())
			return;

		File[] files = dir.listFiles();
		for (int i = 0; i < files.length; i++) {
			/* 递归 */
			compress(files[i], out, basedir + dir.getName() + "/");
		}
	}

}
