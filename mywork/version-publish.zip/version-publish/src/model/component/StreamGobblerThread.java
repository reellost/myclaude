package model.component;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import util.LogUtil;

class StreamGobblerThread extends Thread{
	private final InputStream is;
	private final String streamEncoding;
	final StringBuilder logBuilder;

	StreamGobblerThread(String threadName, InputStream is, String streamEncoding) {
		super(threadName);
		this.setDaemon(true);
		this.is = is;
		this.streamEncoding = streamEncoding;
		this.logBuilder = new StringBuilder(1024 * 1024);
	}

	public void run() {
		BufferedReader br = null;
		try {
			br = new BufferedReader(new InputStreamReader(is, streamEncoding));
			String line = null;
			while ((line = br.readLine()) != null) {
//				logBuilder.append(line).append('\n');
				LogUtil.record(line);
			}
		} catch (Throwable t) {
			System.err.print("<StreamGobblerThread> gobble stream error."+t.getMessage());

		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException ignoreEx) {
				}
			}
		}
	}
}
