package model.component;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.cokutau.common.utils.KuFileUtil;

import config.CustomConfigInfo;
import config.FileType;
import config.VersionPublishHelper;
import config.VersionPublishType;
import model.CompareResult;
import model.FileResult;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import util.CompareUtil;
import util.LogUtil;

public class CompareComponent extends BaseComponent{
	private CompareResult genCompareResult(List<FileResult> list, String publishType, String fileType) {
		CompareResult cmpResult = new CompareResult();
		cmpResult.setType(fileType);
		ObservableList<FileResult> fileList = FXCollections.observableArrayList();
		for(FileResult result: list) {
			result.updatePath(publishType);
			fileList.add(result);
			notifyEvent("文件名："+ result.getOrgPath());
		}
		cmpResult.setFileList(fileList);

		return cmpResult;
	}

	public CompareResult genCompareResultOfFolders(String basePath, String comparePath, List<String> includePathList, List<String> mustExcludePathList) {
		return genCompareResult(compareFoldersWithMultiThread(basePath, comparePath, includePathList, mustExcludePathList, VersionPublishType.GROUP_VERSION_SF), VersionPublishType.GROUP_VERSION_SF, null);
	}

	public CompareResult genCompareResultOfTwoFolder(String basePath, String cachePath, String type, List<String> mustIncludePathList, List<String> excludePathList) {
		return genCompareResult(compareTwoFolderWithMultiThread(basePath, cachePath, type, mustIncludePathList, excludePathList, VersionPublishType.GROUP_VERSION_ZIP), VersionPublishType.GROUP_VERSION_ZIP, type);
	}

	public List<FileResult> compareFoldersWithMultiThread(String basePath, String comparePath, List<String> includePathList, List<String> mustExcludePathList, String publishType){
		notifyEvent("---------------对比开始 --------------");
		notifyEvent("原路径：" + basePath);
		notifyEvent("对比路径：" + comparePath);
		long start = System.currentTimeMillis();

		List<FileResult> list = new CopyOnWriteArrayList<FileResult>();
		for(String path : includePathList) {
			String relativePath = path.replace(basePath + "\\", "");
			String orgPath = basePath + "\\" + relativePath;
			String cachePath = comparePath + "\\" + relativePath;
			File file = new File(orgPath);

			String type = relativePath.startsWith(FileType.SRC) ? FileType.SRC : FileType.RES;

			if(file.isFile()) {
				if(checkIsTargetFile(file, publishType, mustExcludePathList)){
					if(CompareUtil.compareTwoFiles(file.getAbsolutePath(), cachePath) != null) {
						FileResult result = new FileResult(file.getName(), type, file.getAbsolutePath(), cachePath);
						list.add(result);
					}
				}
			}else if(file.isDirectory()){
				realCompareTwoFolder(orgPath, cachePath, type, list, mustExcludePathList, null, publishType);
			}
		}

		long now = System.currentTimeMillis();
		String formatStr = String.format("总共文件: %d (compare cost %d ms)", list.size(), now - start);
		notifyEvent(formatStr);

		return list;
	}


	public List<FileResult> compareTwoFolderWithMultiThread(String basePath, String cachePath, String type, List<String> mustIncludePathList, List<String> excludePathList, String publishType){
		notifyEvent("---------------对比开始 --------------");
		notifyEvent("原路径：" + basePath);
		notifyEvent("缓存路径：" + cachePath);

		long start = System.currentTimeMillis();
		List<FileResult> list = new CopyOnWriteArrayList<FileResult>();
		realCompareTwoFolder(basePath, cachePath, type, list, excludePathList, mustIncludePathList, publishType);

		long now = System.currentTimeMillis();
		String costTimeStr = "cost " + (now - start) + " ms";
		notifyEvent(String.format("总共文件: %d (%s)", list.size(), costTimeStr));

		return list;
	}

	private void realCompareTwoFolder(String orgPath, String cachePath, String type, List<FileResult> list, List<String> excludePathList, List<String> mustIncludePathList, String publishType) {
		LogUtil.record(String.format("prepare to compare folder: %s <=> %s", orgPath, cachePath));
		List<String> needCompareFileList = new ArrayList<String>();
		LogUtil.record("start search files...");
		findAllFiles(orgPath, needCompareFileList, publishType, excludePathList, mustIncludePathList);
		LogUtil.record(String.format("found %d files", needCompareFileList.size()));
		LogUtil.record("now start compare one by one, please wait...");
		ExecutorService threadPool = Executors.newFixedThreadPool((int)(Runtime.getRuntime().availableProcessors()*1.5));
		CountDownLatch cd = new CountDownLatch(needCompareFileList.size());
		for(String filepath : needCompareFileList) {
			threadPool.execute(new Runnable() {
				@Override
				public void run() {
					try {
						File file = new File(filepath);
						String cmpPath = file.getAbsolutePath().replace(orgPath, cachePath);
						if(CompareUtil.compareTwoFiles(file.getAbsolutePath(), cmpPath) != null) {
							FileResult result = new FileResult(file.getName(), type, file.getAbsolutePath(), cmpPath);
							list.add(result);
						}
					}finally {
						cd.countDown();
					}
				}
			});
		}

		try {
			cd.await();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		threadPool.shutdown();
	}

	private void findAllFiles(String curPath, List<String> fileList, String publishType, List<String> excludePathList, List<String> mustIncludePathList) {
		File root = new File(curPath);
		File[] files = root.listFiles();
		for(File file : files){
			String absolutePath = file.getAbsolutePath();
			if(file.isDirectory()){
				findAllFiles(absolutePath,fileList, publishType, excludePathList, mustIncludePathList);
			}else if(checkIsTargetFile(file, publishType, excludePathList, mustIncludePathList)){
				fileList.add(absolutePath);
			}
		}
	}

	private boolean checkIsTargetFile(File file, String publishType, List<String> excludePathList){
		return checkIsTargetFile(file, publishType, excludePathList, null);
	}

	private boolean checkIsTargetFile(File file, String publishType, List<String> excludePathList, List<String> mustIncludePathList){
		String abspath = file.getAbsolutePath();
		if(VersionPublishHelper.isIgnoreFile(file)){
			LogUtil.record("ignore file:" + abspath);
			return false;
		}

		if(checkInPathList(abspath, mustIncludePathList)){
			return true;
		}

		boolean match = false;

		switch(publishType){
			case VersionPublishType.GROUP_VERSION_ZIP:
				match = !checkInPathList(abspath, excludePathList) || !VersionPublishHelper.isExcludeFile(file);
				break;
			case VersionPublishType.GROUP_VERSION_SF:
				match = !checkInPathList(abspath, excludePathList);
				break;
			default:
				break;
		}

		return match;
	}

	private boolean checkInPathList(String path, List<String> filepathList) {
		if(filepathList != null) {
			for(int i = 0; i < filepathList.size(); i++) {
				if(path.startsWith(filepathList.get(i))) {
					return true;
				}
			}
		}

		return false;
	}

	public void addDeleteFiles(String orgPath, String cachePath, List<String> array, String type){
		// 寻找删除的文件
		int count = findDeleteFiles(cachePath, cachePath, orgPath, array, VersionPublishHelper.getCustomConfigInfo().basePath + "\\");
		notifyEvent(String.format("%s删除文件数量:%d", type, count));
	}

	private int findDeleteFiles(String curPath, String basePath, String comparePath, List<String> array, String prefixPath) {
		int count = 0;
		File root = new File(curPath);
		File[] files = root.listFiles();
		if(files != null){
			for(File file : files) {
				if(file.isFile()) {
					String targetPath = file.getAbsolutePath().replace(basePath, comparePath);
					if(!KuFileUtil.isFileExist(targetPath)) {
						count++;
						String relativePath = targetPath.replace(prefixPath, "\\");
						array.add(relativePath);
					}
				}else {
					count += findDeleteFiles(file.getAbsolutePath(), basePath, comparePath, array, prefixPath);
				}
			}
		}

		return count;
	}
}
