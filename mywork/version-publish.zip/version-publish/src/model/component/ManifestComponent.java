package model.component;

import java.io.File;
import java.util.Date;

import com.alibaba.fastjson.JSONObject;

import config.VersionPublishHelper;
import config.manifest.ProjectManifestData;
import model.event.CommonEvent;
import util.HttpUtil;
import util.JsonFileUtil;
import util.LogUtil;

public class ManifestComponent extends BaseComponent{
	private ProjectManifestData _projectManifestData;

	public ProjectManifestData getPrjManifestData(){
		return _projectManifestData;
	}
	/**
	*向服务器获取project.manifest 并生成perojectManidestData
	* perojectManidestData的信息通过project.manifest生成
	*/
	public ProjectManifestData getRemoteManifest(String publishType){
		Date date = new Date();
		String url = VersionPublishHelper.getCustomConfigInfo().getProjectUrl(publishType);
		boolean ret = false;
		if(url != null) {
			notifyEvent("下载project.manifest文件中，请等待...", CommonEvent.EventType.OUT_MSG);
			String projectUrl = VersionPublishHelper.getCustomConfigInfo().getProjectUrl(publishType) + "?" + date.getTime();
			ret = this.downProjectManifest(projectUrl);
		}

		if(!ret) {
			_projectManifestData = ProjectManifestData.getInitProjectManifestData();
			notifyEvent("下载manifest文件失败，请检查url和域名配置是否正确，首次发布大版本可忽略", CommonEvent.EventType.OUT_MSG);
		}else{
			LogUtil.record("下载manifest成功");
		}
		return _projectManifestData;
	}

	private boolean downProjectManifest(String url){
		String pfile = VersionPublishHelper.getWorkspaceConfig().getProjectManifestPath();
		HttpUtil.downloadFile(url, pfile);
		if(new File(pfile).exists()){
			_projectManifestData = (ProjectManifestData)JsonFileUtil.readJson(pfile, ProjectManifestData.class);
			return true;
		}else{
			return false;
		}
	}

	public ProjectManifestData getTestManifest() {
		String filePath = VersionPublishHelper.getWorkspaceConfig().getTmpProjectManifestPath();
		LogUtil.record("use test manifest: " + filePath);
		_projectManifestData = (ProjectManifestData)JsonFileUtil.readJson(filePath, ProjectManifestData.class);
		return _projectManifestData;
	}
}
