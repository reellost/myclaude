package model.handler;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpEntity;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.FileBody;

import com.alibaba.fastjson.JSON;
import com.cokutau.common.utils.KuFileUtil;

import config.CustomConfigInfo;
import config.FileType;
import config.VersionPublishHelper;
import config.WorkspaceConfigInfo;
import config.manifest.AssetData;
import config.manifest.ProjectManifestData;
import model.CompareResult;
import model.ExecuteResult;
import util.LogUtil;

public class ZipVersionHandler extends VersionHandlerBase{
	@Override
	public ExecuteResult doCompare() {
		compareResults.clear();
		//src or res
		String[] types = FileType.types;
		CustomConfigInfo customInfo = VersionPublishHelper.getCustomConfigInfo();

		for (String type : types){
			String cachePath = customInfo.getCachePath(type);
			String orgPath   = customInfo.getBasePath(type);

			List<String> excludeFileList = customInfo.getExcludeFileList(type);
			List<String> mustIncludeFileList = customInfo.getIncludeFileList(type);

			CompareResult compareResult = _compareComponent.genCompareResultOfTwoFolder(orgPath, cachePath, type, mustIncludeFileList, excludeFileList);
			if(!compareResult.isEmpty()){
				compareResults.add(compareResult);
			}
		}

		if(compareResults.isEmpty()){
			return new ExecuteResult(false, "没有不同");
		}else{
			return new ExecuteResult(true, "对比完成");
		}
	}

	@Override
	public boolean packageAction() {
		String nextVersion = getManifestData().tmpGroupVersion;
		return _packageComponent.packageCompareResults(compareResults, nextVersion);
	}

	protected void saveUploadRecord(){
		// 保存一下此次生成的zip
		LogUtil.record("start to save zip file.please wait...");
		String version = getManifestData().tmpGroupVersion;
		WorkspaceConfigInfo configInfo = VersionPublishHelper.getWorkspaceConfig();
		String zipPath = configInfo.getRecordPath() + WorkspaceConfigInfo.ZIP_PATH_SUFFIX;
		boolean ret = true;
		for(CompareResult cmpResult: compareResults) {
			String zipName = configInfo.getZipName(cmpResult.getType(), version);
			String fileName = String.format("%s\\%s.zip", zipPath, cmpResult.getType() + version);
			try {
				KuFileUtil.copyFile(new File(zipName), new File(fileName));
				LogUtil.record("save zip file success: " + fileName);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				LogUtil.recordErr(e.getMessage());
				ret = false;
			}
		}

		String tips = ret ? String.format("see zip file in %s", zipPath) : "save zip file failed.";
		LogUtil.record(tips);
	}

	@Override
	@SuppressWarnings("unchecked")
	protected void prepareAssetsData() {
		ProjectManifestData data = getManifestData();
		if(data.assets == null) {
			data.tmpAssets = new HashMap<>();
		}else {
			data.tmpAssets = (HashMap<String, AssetData>) data.assets.clone();
		}

		String nextVersion = getManifestData().tmpGroupVersion;
		for(CompareResult compareResult : compareResults) {
			data.updateTmpAssetData(compareResult.getType(), nextVersion);
		}
	}

	private static final int ignoreReduceOldPackageMinSize = 1024 * 1024 * 10;

	@Override
	protected HttpEntity createHttpEntity() {
		ProjectManifestData manifestData = getManifestData();

		MultipartEntityBuilder builder = MultipartEntityBuilder.create();
		builder.addTextBody("versionTag", VersionPublishHelper.getCustomConfigInfo().versionTag);
		builder.addTextBody("version", manifestData.tmpVersion);
		builder.addTextBody("engineVersion", manifestData.engineVersion);
		builder.addTextBody("groupVersion", manifestData.tmpGroupVersion);
//		builder.addTextBody("groupVersions", "");

		int c = 0;
		for (Map.Entry<String, AssetData> entry : manifestData.tmpAssets.entrySet()) {
			AssetData assetData = entry.getValue();
			builder.addTextBody("key" + c, entry.getKey());
			builder.addTextBody("compressed" + c, assetData.compressed ? "true" : "false");
			builder.addTextBody("md5" + c, assetData.md5);
			builder.addTextBody("tag" + c, String.valueOf(assetData.tag));
			long size = assetData.size;

			if(assetData.changed) {
				File file = new File(assetData.path);
				builder.addPart("file" + c, new FileBody(file));
			}

			builder.addTextBody("size" + c, String.valueOf(size));
			LogUtil.record("---asset size :" + size + "  " + entry.getKey());
//			notifyEvent("upload file params:" + size + "  " + entry.getKey() + "\n");
			c++;
		}

		String jsonStr = JSON.toJSONString(getDeleteFiles());
		builder.addTextBody("deleteFiles", jsonStr);
		builder.addTextBody("fileCount", String.valueOf(c));
		builder.addTextBody("ignoreReduceOldPackageMinSize", String.valueOf(ignoreReduceOldPackageMinSize));
		return builder.build();
	}

	public ArrayList<String> getDeleteFiles(){
		CustomConfigInfo customInfo = VersionPublishHelper.getCustomConfigInfo();
		ArrayList<String> fileList = new ArrayList<String>();
		for (int i = 0; i < FileType.types.length; i++) {
			String type = FileType.types[i];
			String orgPath   = customInfo.getBasePath(type);
			String cachePath = customInfo.getCachePath(type);
			_compareComponent.addDeleteFiles(orgPath, cachePath, fileList, type);
		}

		return fileList;
	}
}
