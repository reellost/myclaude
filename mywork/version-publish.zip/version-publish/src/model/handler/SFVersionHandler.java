package model.handler;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpEntity;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.FileBody;

import com.cokutau.common.utils.KuFileUtil;

import config.VersionPublishHelper;
import config.VersionPublishType;
import config.manifest.AssetData;
import config.manifest.ProjectManifestData;
import model.CompareResult;
import model.ExecuteResult;
import model.FileResult;
import util.LogUtil;

public class SFVersionHandler extends VersionHandlerBase{
	@Override
	public ExecuteResult doCompare() {
		compareResults.clear();

		// 此处拿到的已经是绝对路径
		List<String> includeFileList = VersionPublishHelper.getCustomConfigInfo().getExcludeFileList();
		if(includeFileList.size() == 0) {
			return new ExecuteResult(false, "没有可对比的文件/目录");
		}

		LogUtil.record("start compare");

		//只对包含的路径文件夹做对比
		String orgPath = VersionPublishHelper.getCustomConfigInfo().basePath;
		String cachePath = VersionPublishHelper.getCustomConfigInfo().cachePath;

		List<String> excludeFileList = VersionPublishHelper.getCustomConfigInfo().getIncludeFileList();

		CompareResult compareResult = _compareComponent.genCompareResultOfFolders(orgPath, cachePath, includeFileList, excludeFileList);
		if(!compareResult.isEmpty()){
			compareResults.add(compareResult);
		}

		if(compareResults.isEmpty()){
			return new ExecuteResult(false, "没有不同");
		}else{
			return new ExecuteResult(true, "对比完成");
		}
	}

	@Override
	public boolean packageAction() {
		return _packageComponent.packageAssets();
	}

	@Override
	protected void prepareAssetsData() {
		ProjectManifestData data = getManifestData();

		data.tmpAssets = new HashMap<>();
		String orgPath = VersionPublishHelper.getCustomConfigInfo().basePath;
		String cachePath = VersionPublishHelper.getCustomConfigInfo().cachePath;
		// 1.将manifest中存在但项目工程中已不存在的文件对应的AssetsData剔除
		for(Map.Entry<String, AssetData> entry: data.assets.entrySet()) {
			AssetData assetData = entry.getValue();
			if(KuFileUtil.isFileExist(orgPath + "\\" + entry.getKey())) {
				data.tmpAssets.put(entry.getKey(), assetData);
			}else {
				// 如果不在原目录中出现，但在备份目录中出现，则代表需要删除
				String filePath = cachePath + "\\" + entry.getKey();
				if(KuFileUtil.isFileExist(filePath)) {
					deleteFiles.add(filePath);
				}
			}
		}

		// 2.将所有对比出来的差异文件放入AssetsData中，如果已有，则更新md5
		for(CompareResult compareResult : compareResults) {
			for(FileResult fileResult : compareResult.getFileList()) {
				data.updateTmpAssetData(fileResult);
			}
		}
	}

	@Override
	protected HttpEntity createHttpEntity() {
		ProjectManifestData manifestData = getManifestData();

		MultipartEntityBuilder builder = MultipartEntityBuilder.create();
		builder.addTextBody("versionTag", VersionPublishHelper.getCustomConfigInfo().versionTag);
		builder.addTextBody("version", manifestData.tmpVersion);
		builder.addTextBody("engineVersion", manifestData.engineVersion);
		builder.addTextBody("groupVersion", manifestData.tmpGroupVersion);

		if(publishType == VersionPublishType.GROUP_VERSION_SF) {
			File file = new File(VersionPublishHelper.getWorkspaceConfig().getZipName());
			builder.addPart("file", new FileBody(file));
		}

		int c = 0;
		for (Map.Entry<String, AssetData> entry : manifestData.tmpAssets.entrySet()) {
			AssetData assetData = entry.getValue();
			builder.addTextBody("key" + c, assetData.key);
			builder.addTextBody("md5" + c, assetData.md5);
			builder.addTextBody("path" + c, assetData.path != null ? assetData.path : assetData.key.replace("/", "."));
			if(assetData.fbl != null){
				builder.addTextBody("fbl" + c, assetData.fbl);
			}
			long size = assetData.size;

			builder.addTextBody("size" + c, String.valueOf(size));
//			LogUtil.record("---size :" + size + "  " + entry.getKey());
//			notifyEvent("upload file params:" + size + "  " + entry.getKey() + "\n");
			c++;
		}

		builder.addTextBody("fileCount", String.valueOf(c));
		return builder.build();
	}
}
