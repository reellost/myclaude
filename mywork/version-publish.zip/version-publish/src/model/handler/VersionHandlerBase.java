package model.handler;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import javafx.application.Platform;
import javafx.stage.Stage;
import com.cokutau.common.utils.KuFileUtil;

import ui.BasePanel;
import ui.FloatTips;
import ui.TipPanel;
import util.LogUtil;
import config.CustomConfigInfo;
import config.FileType;
import config.VersionPublishHelper;
import config.VersionPublishType;
import config.manifest.ProjectManifestData;
import model.component.CompareComponent;
import model.component.ManifestComponent;
import model.component.PackageComponent;
import model.event.CommonEvent;
import model.event.OutputManager;
import model.CompareResult;
import model.ExecuteResult;
import model.FileResult;

public abstract class VersionHandlerBase {
	protected ManifestComponent _manifestComponent;
	protected CompareComponent _compareComponent;
	protected PackageComponent _packageComponent;

	protected ArrayList<CompareResult> compareResults;
	protected ArrayList<String> deleteFiles;

	protected String publishType = null;

	public enum PublishState{
		INIT,
		COMPARE_FAIL,
		COMPARE_SUC,
		PACKAGE_FAIL,
		PACKAGE_SUC,
		UPLOAD_FAIL,
		UPLOAD_SUC,
	}

	protected PublishState _publishState;

	public VersionHandlerBase() {
		_manifestComponent = new ManifestComponent();
		_compareComponent = new CompareComponent();
		_packageComponent = new PackageComponent();

		compareResults = new ArrayList<>();
		deleteFiles = new ArrayList<>();
		_publishState = PublishState.INIT;
	}

	public boolean reachState(PublishState state) {
		return _publishState.ordinal() >= state.ordinal();
	}

	public boolean hasDiff() {
		return !compareResults.isEmpty();
	}

	protected static boolean TEST = false;

	public boolean initManifest(String publishType) {
		this.publishType = publishType;

		ProjectManifestData data = TEST ? getTestManifest() : getRemoteManifest();
		data.initProjectInfo(publishType);
		return !data.isTempData;
	}

	public ProjectManifestData getManifestData() {
		return _manifestComponent.getPrjManifestData();
	}

	public ProjectManifestData getRemoteManifest() {
		return _manifestComponent.getRemoteManifest(publishType);
	}

	public ProjectManifestData getTestManifest() {
		return _manifestComponent.getTestManifest();
	}

	public void testPackage(String source, String target){
		_packageComponent.zipFiles(source, target);
	}

	public void compareAndEncript(BasePanel panel){
		TipPanel tipPanel = showTipPanel("对比中...", panel.getStage());
		ExecuteResult result = doCompare();

		tipPanel.setText(result.msg);
		if(result.ret){
			tipPanel.close();
			doEncript(panel);
		}else{
			_publishState = PublishState.COMPARE_FAIL;
		}
	}

	public abstract ExecuteResult doCompare();

	public void doEncript(BasePanel panel){
		TipPanel tipPanel = showTipPanel("加密中...", panel.getStage());
		Thread thread = new Thread(new Runnable(){
			@Override
			public void run() {
				ExecuteResult result = _packageComponent.encriptCompareResult(compareResults);
				Platform.runLater(()->tipPanel.setText(result.msg));
				if(result.ret) {
					Platform.runLater(()->_packageComponent.notifyEvent(String.format("加密成功(cost %d ms)", result.time)));
					_publishState = PublishState.COMPARE_SUC;
				}else {
					_publishState = PublishState.COMPARE_FAIL;
				}
			}
		});

		thread.start();
	}

	public void doPackage(BasePanel panel) {
		if(!reachState(PublishState.COMPARE_SUC)) {
			FloatTips.makeText(panel.getStage(), "没有差异文件，无法打包").show();
			return;
		}

		if(reachState(PublishState.PACKAGE_SUC)) {
			FloatTips.makeText(panel.getStage(), "已经打包成功，无需重复操作").show();
			return;
		}

		boolean ret = packageAction();
		if(ret) {
			_publishState = PublishState.PACKAGE_SUC;
			FloatTips.makeText(panel.getStage(), "打包成功").show();
//			showTipPanel("打包成功", panel.getStage());
		}else {
			showTipPanel("打包失败", panel.getStage());
			_publishState = PublishState.PACKAGE_FAIL;
		}
	}

	protected abstract boolean packageAction();

	protected abstract void prepareAssetsData();

	protected abstract HttpEntity createHttpEntity();

	public void doUpload(BasePanel panel) {
		if(reachState(PublishState.UPLOAD_SUC)) {
			boolean ok = true;
			if(VersionPublishType.isGroupType(publishType)) {
				ok = updateCacheFiles();
			}
			if(ok) {
				panel.close();
				showTipPanel("上传成功", new Stage());
			}else {
				showTipPanel("上传成功，但更新缓存失败，需要手动同步一下以上文件", new Stage());
			}

			return;
		}

		TipPanel tipPanel = showTipPanel("请等待...", panel.getStage());

		if(VersionPublishType.isGroupType(publishType)) {
			if(!reachState(PublishState.COMPARE_SUC)) {
				tipPanel.setText("没有差异文件，无法上传");
				return;
			}

			doPackage(panel);

			if(!reachState(PublishState.PACKAGE_SUC)) {
				return;
			}

			prepareAssetsData();
		}

		tipPanel.setText("上传中...");

		boolean ok = startUpload();

		if(ok)
		{
			if(VersionPublishType.isGroupType(publishType)) {
				ok = updateCacheFiles();
				// 记录一下此次上传的文件
				saveUploadRecord();
			}
			if(ok) {
				panel.close();
				tipPanel.close();
				showTipPanel("上传成功", new Stage());
			}else {
				tipPanel.setText("上传成功，但更新缓存失败，请重试");
			}
		}
		else
		{
			tipPanel.setText("上传失败！");
		}
	}

	protected void saveUploadRecord(){
		LogUtil.record("Please rewrite this method");
	}

	private boolean startUpload() {
		_publishState = PublishState.UPLOAD_FAIL;

		boolean ret = false;

		String uploadUrl = VersionPublishHelper.getCustomConfigInfo().getUploadUrl(publishType);
		HttpPost httppost = new HttpPost(uploadUrl);
		httppost.setEntity(createHttpEntity());

		LogUtil.record("start upload.url:" + uploadUrl);

		CloseableHttpClient httpclient = HttpClients.createDefault();
		try {
			CloseableHttpResponse response = httpclient.execute(httppost);
			LogUtil.record("response status code: "+ response.getStatusLine().getStatusCode());
			LogUtil.record("ReasonPhrase: " + response.getStatusLine().getReasonPhrase());
			OutputManager.getInstance().notifyEvent(CommonEvent.EventType.OUT_MSG, "上传返回:" + uploadUrl + "\n状态码为:" + response.getStatusLine().getStatusCode() + "\n");
			if (response.getStatusLine().getStatusCode() == 200) {
				HttpEntity resEntity = response.getEntity();
				String content = EntityUtils.toString(resEntity);

				if(content.endsWith("SUCCESS")) {
					LogUtil.record("上传成功！" + content);
					EntityUtils.consume(resEntity);
					_publishState = PublishState.UPLOAD_SUC;
					ret = true;
				}else {
					LogUtil.record("上传失败！原因:" + content);
				}
			}
		} catch (Throwable e) {
			e.printStackTrace();
		} finally {
			try {
				httpclient.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		return ret;
	}

	public void clearWorkDir() {
		VersionPublishHelper.clearWorkDirectory();
	}

	public boolean updateCacheFiles(){
		boolean ret = false;
		switch(publishType) {
		case VersionPublishType.BIG_VERSION_SF:
		case VersionPublishType.BIG_VERSION_ZIP:
			ret = updateAllCacheFiles();
			break;
		case VersionPublishType.GROUP_VERSION_SF:
		case VersionPublishType.GROUP_VERSION_ZIP:
			ret = updateCmpCacheFiles();
			break;
		default:
			break;
		}

		return ret;
	}

	protected boolean updateCmpCacheFiles(){
		LogUtil.record("start to update compare results");
		boolean ret = true;

		for(CompareResult compareResult : compareResults) {
			for(FileResult fResult : compareResult.getFileList()){
				try{
					KuFileUtil.copyFile(new File(fResult.getOrgPath()), new File(fResult.getCachePath()));
				} catch (IOException e) {
					ret = false;
					LogUtil.record("拷贝文件失败:" + fResult.getOrgPath() + "  =>  " + fResult.getCachePath());
//					e.printStackTrace();
				}

			}
		}

		for(String filePath: deleteFiles) {
			File file = new File(filePath);
			if(file.exists()) {
				try{
					file.delete();
				}catch(SecurityException e) {
					ret = false;
					LogUtil.record("删除文件失败:" + filePath);
				}
			}
		}

		return ret;
	}

	protected boolean updateAllCacheFiles() {
		LogUtil.record("start to update all cache files");
		boolean ret = false;
		try {
			CustomConfigInfo customConfig = VersionPublishHelper.getCustomConfigInfo();
			File file = new File(customConfig.getCachePath());
			KuFileUtil.forceMkdir(file);

			for (int i = 0; i < FileType.types.length; i++) {
				String type = FileType.types[i];
				String basePath = customConfig.getBasePath(type);
				String cachePath = customConfig.getCachePath(type);
				LogUtil.record("basePath " + basePath);
				LogUtil.record("cachePath " + cachePath);
				KuFileUtil.deleteDirectory(new File(cachePath));
				KuFileUtil.copyDirectoryToDirectory(new File(basePath), file);
			}

			ret = true;
		} catch (IOException e) {
			ret = false;
			e.printStackTrace();
		}

		return ret;
	}

	protected TipPanel showTipPanel(String str, Stage stage){
		TipPanel pane = new TipPanel(stage, str);
		pane.show();
		return pane;
	}
}
