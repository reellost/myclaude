package model.event;

import java.util.EventListener;

public abstract class CommonListener implements EventListener{
	abstract public void handleEvent(CommonEvent event);
}
