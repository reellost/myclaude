package model.event;

import java.util.EventObject;

public class CommonEvent extends EventObject{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5649379409970535645L;
	
	public static enum EventType{
		OUT_MSG,
		INNER_MSG
	}
	
	public String msg;
	public EventType type;
	
	public CommonEvent(Source source) {
		super(source);
		// TODO Auto-generated constructor stub
	}
	
	public CommonEvent(Source source, EventType type, String msg) {
		super(source);
		
		this.type = type;
		this.msg = msg;
	}
}
