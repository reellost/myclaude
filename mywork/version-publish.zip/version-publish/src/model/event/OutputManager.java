package model.event;

public class OutputManager extends Source{
	private static OutputManager _instance;
	private OutputManager() {
		
	}
	
	public static OutputManager getInstance() {
		if(_instance == null) {
			_instance = new OutputManager();
		}
		return _instance;
	}
	
}
