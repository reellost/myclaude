package model.event;

import java.util.HashSet;
import java.util.Set;

public class Source {
	Set<CommonListener> listeners = new HashSet<CommonListener>();
	
	public void addListener(CommonListener listener) {
		listeners.add(listener);
	}
	
	public void removeListener(CommonListener listener) {
		listeners.remove(listener);
	}
	
	public void removeListeners() {
		listeners.clear();
	}
	
	public void notifyEvent(CommonEvent.EventType type, String msg) {
		CommonEvent event = new CommonEvent(this, type, msg);
		for(CommonListener listener: listeners) {
			listener.handleEvent(event);
		}
	}
}
