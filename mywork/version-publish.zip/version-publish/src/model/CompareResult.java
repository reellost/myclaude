package model;

import javafx.collections.ObservableList;

public class CompareResult {
	private ObservableList<FileResult> _fileList;
	private String _type;
	
	public void setFileList(ObservableList<FileResult> fileList){
		this._fileList = fileList;
	}

	public ObservableList<FileResult> getFileList() {
		return _fileList;
	}
	
	public boolean isEmpty(){
		return getFileList().toArray().length <= 0;
	}
	
	public String getType() {
		return _type;
	}

	public void setType(String type) {
		this._type = type;
	}
}
