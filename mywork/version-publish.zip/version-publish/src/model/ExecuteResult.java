package model;

public class ExecuteResult {
	public boolean ret;
	public String msg;
	public long time;

	public ExecuteResult(boolean r) {
		this(r, r ? "success" : "failed", 0);
	}

	public ExecuteResult(boolean r, String str) {
		this(r, str, 0);
	}

	public ExecuteResult(boolean r, String str, long l) {
		ret = r;
		msg = str;
		time = l;
	}
}
