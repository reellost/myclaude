package ui;

import java.io.IOException;

import fxml.ViewPath;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.stage.Window;
import util.LogUtil;

public abstract class BasePanel extends AnchorPane{
	protected Stage stage;
	protected Runnable onClose;

	public BasePanel(Window owner, String fxmlPath) {
		this(owner, fxmlPath, "", null);
	}

	public BasePanel(Window owner, String fxmlPath, String title) {
		this(owner, fxmlPath, title, null);
	}

	public BasePanel(Window owner, String fxmlPath, String title, Runnable onClose) {
		stage = new Stage();
		FXMLLoader loader = new FXMLLoader(ViewPath.class.getResource(fxmlPath));
		loader.setRoot(this);
		loader.setController(this);
		try {
			Scene scene = new Scene((Parent) loader.load());
			stage.initStyle(StageStyle.DECORATED);
			stage.setScene(scene);
			stage.setResizable(false);
			stage.initOwner(owner);
			stage.initModality(Modality.APPLICATION_MODAL);
			stage.setTitle(title);
			this.onClose = onClose;
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	abstract protected boolean init();

	public void show() {
		boolean ret = init();
		if(ret){
			stage.show();
		}else{
			String className = new Exception().getStackTrace()[0].getClassName(); //获取调用者的类名
			LogUtil.record(String.format("show [%s] failed.", className));
		}
	}

	public Stage getStage() {
		return stage;
	}

	public void close() {
		stage.close();
		if (onClose != null) {
			onClose.run();
		}
	}

	public void setCloseFunc(Runnable runnable){
		onClose = runnable;
	}
}
