package ui;

import java.io.IOException;

import config.VersionPublishHelper;
import config.VersionPublishType;
import javafx.fxml.FXML;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextArea;
import javafx.stage.Window;
import model.ExecuteResult;
import model.event.CommonEvent;
import model.event.CommonListener;
import model.event.OutputManager;
import ui.publish.BigVersionPublishPanel;
import ui.publish.SFGroupPublishPanel;
import ui.publish.ZipGroupPublishPanel;
import util.JsonFileUtil;
import util.LogUtil;

public class MainPanel extends BasePanel {
	protected static String FXML_PATH = "MainPane.fxml";
	protected static String TITLE = "version publish";

	protected CommonListener listener;

	@FXML
	TabPane tabPane;
	@FXML
	Tab tabLua;
	@FXML
	Tab tabRes;
	@FXML
	public TextArea txtOutput;

	public MainPanel(Window owner) {
		super(owner, FXML_PATH, TITLE);
	}

	@Override
	protected boolean init() {
		// TODO Auto-generated method stub
		initListeners();

		try {
			String str = JsonFileUtil.getStr(fxml.ViewPath.class.getResourceAsStream("readme.txt"));
			txtOutput.setText(str);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			LogUtil.recordErr(e.getMessage());
		}

		return true;
	}

	private void initListeners() {
		listener = new CommonListener() {
			@Override
			public void handleEvent(CommonEvent event) {
				if(event.type == CommonEvent.EventType.OUT_MSG) {
					outputContent(event.msg);
				}
			}
		};
		OutputManager.getInstance().addListener(listener);
	}

	public boolean checkCanStartPublish(){
		ExecuteResult result = VersionPublishHelper.checkPathValid();
		if(!result.ret){
			LogUtil.record(result.msg);
			FloatTips.makeText(stage, result.msg).show();
		}

		return result.ret;
	}

	@FXML
	public void onBtnZipGroupAction() {
		if(!checkCanStartPublish()){
			return;
		}
		new ZipGroupPublishPanel(stage).show();
	}

	@FXML
	public void onBtnSFGroupAction() {
		if(!checkCanStartPublish()){
			return;
		}
		new SFGroupPublishPanel(stage).show();
	}

	@FXML
	public void onBtnZipBigAction() {
		if(!checkCanStartPublish()){
			return;
		}
		new BigVersionPublishPanel(stage, VersionPublishType.BIG_VERSION_ZIP).show();
	}

	@FXML
	public void onBtnSFBigAction() {
		if(!checkCanStartPublish()){
			return;
		}
		new BigVersionPublishPanel(stage, VersionPublishType.BIG_VERSION_SF).show();
	}

	@FXML
	public void onBtnSetupAction() {
		new SettingPanel(stage, null).show();
	}

	public void outputContent(String str){
		String org = txtOutput.getText();
		txtOutput.setText(org + str);
		txtOutput.end();
	}

	public void close() {
		super.close();
		OutputManager.getInstance().removeListener(listener);
	}
}
