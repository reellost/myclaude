package ui;

import javafx.fxml.FXML;
import javafx.stage.Window;

public class SurePanel extends BasePanel {
	protected static final String FXML_PATH = "SurePane.fxml";
	protected static final String TITLE = "确定？";

	Runnable okfunc;
	Runnable cancelfunc;

	public SurePanel(Window owner, Runnable okfunc, Runnable cancelfunc){
		super(owner, FXML_PATH, TITLE);

		this.okfunc = okfunc;
		this.cancelfunc = cancelfunc;
	}

	@Override
	protected boolean init() {
		// TODO Auto-generated method stub
		return true;
	}

	@FXML
	public void onBtnCancelAction(){
		this.close();
		if (this.cancelfunc != null){
			this.cancelfunc.run();
		}
	}

	@FXML
	public void onBtnOkAction(){
		this.close();
		if (this.okfunc != null){
			this.okfunc.run();
		}
	}
}
