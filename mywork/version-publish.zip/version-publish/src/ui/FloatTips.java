package ui;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.stage.Window;
import javafx.util.Duration;

public class FloatTips extends BasePanel{
	protected static final String FXML_PATH = "FloatTips.fxml";

	private String text;

	@FXML
	Label label;

	private FloatTips(Window owner, String tips) {
		super(owner, FXML_PATH);
		text = tips;
		stage.initStyle(StageStyle.UNDECORATED);  // 无标题栏
	}

	@Override
	protected boolean init() {
		label.setText(text);

		return true;
	}

	public void show(){
		super.show();

		Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(1), (ActionEvent t) -> close()));
		timeline.setCycleCount(1);
		timeline.play();
	}

	public static FloatTips makeText(Window owner, String tips){
		FloatTips floatTips = new FloatTips(owner, tips);
		floatTips.show();
		return floatTips;
	}
}
