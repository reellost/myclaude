package ui;

import java.io.File;
import java.util.List;

import config.CustomConfigInfo;
import config.VersionPublishHelper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.input.ClipboardContent;
import javafx.scene.input.DragEvent;
import javafx.scene.input.Dragboard;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.TransferMode;
import javafx.stage.DirectoryChooser;
import javafx.stage.Window;
import javafx.util.Callback;
import model.ExecuteResult;
import util.LogUtil;

public class SettingPanel extends BasePanel {
	protected static final String FXML_PATH = "SettingPane.fxml";
	protected static final String TITLE = "SetUp";

	@FXML
	TextField txtBasePath;
	@FXML
	TextField txtCachePath;
	@FXML
	TextField txtVersionTag;
	@FXML
	TextField txtProjectUrl;
	@FXML
	TextField txtUploadUrl;
	@FXML
	TextField txtDelelteUrl;
	@FXML
	TextField txtIgnoreFiles;
	@FXML
	TextField txtSuffix;
	@FXML
	TextField txtCompareFolderName;

	@FXML
	TextField txtScriptExt;

	@FXML
	public ListView<String> pathListView1;

	@FXML
	public ListView<String> pathListView2;

	private CustomConfigInfo pathInfo;

	private ObservableList<String> excludeFileList;

	private ObservableList<String> includeFileList;

	public SettingPanel(Window owner, Runnable close) {
		super(owner, FXML_PATH, TITLE, close);
	}

	@Override
	protected boolean init() {
		pathInfo = VersionPublishHelper.getCustomConfigInfo();

		txtBasePath.setText(pathInfo.basePath);
		txtCachePath.setText(pathInfo.cachePath);
		txtVersionTag.setText(pathInfo.versionTag);
		txtProjectUrl.setText(pathInfo.getProjectUrl(null));
		txtUploadUrl.setText(pathInfo.getUploadUrl(null));
		txtDelelteUrl.setText(pathInfo.getDeleteUrl(null));
		txtIgnoreFiles.setText(pathInfo.ignoreFiles);
		txtSuffix.setText(pathInfo.excludeSuffix);
		txtCompareFolderName.setText(pathInfo.compareFolderName);
		txtScriptExt.setText(pathInfo.scriptExt);

		excludeFileList = readFileStr(pathInfo.excludeFiles);
		includeFileList = readFileStr(pathInfo.includeFiles);

		initListView(pathListView1, excludeFileList);
		initListView(pathListView2, includeFileList);
		return true;
	}

	private ObservableList<String> readFileStr(String files){
		ObservableList<String> resultList = FXCollections.observableArrayList();
		if(files != null && !files.isEmpty()) {
			String[] pathList = files.split(";");
			for(int i = 0; i < pathList.length; i++) {
				resultList.add(pathList[i]);
			}
		}

		return resultList;
	}

	public void initListView(ListView<String> pathListView, final ObservableList<String> dataList) {
		pathListView.setCellFactory(new Callback<ListView<String>, ListCell<String>>(){
			@Override
			public ListCell<String> call(ListView<String> param) {
				// TODO Auto-generated method stub
				ListCell<String> cell = new ListCell<String>() {
					@Override
					protected void updateItem(String path, boolean empty) {
						super.updateItem(path, empty);
						setText(path);
					}
				};

				cell.setOnDragDetected(new EventHandler<MouseEvent>() {
					@Override
					public void handle(MouseEvent event) {
						// TODO Auto-generated method stub
						Dragboard dragboard = cell.startDragAndDrop(TransferMode.ANY);
						ClipboardContent content = new ClipboardContent();
						content.putString(cell.getText());
						dragboard.setContent(content);
					}
				});

				return cell;
			}
		});

		pathListView.setOnDragOver(new EventHandler<DragEvent>() {
			@Override
			public void handle(DragEvent event) {
				event.acceptTransferModes(TransferMode.ANY);
			}
		});

		pathListView.setOnDragDropped(new EventHandler<DragEvent>() {
			@Override
			public void handle(DragEvent event) {
				Dragboard dragboard = event.getDragboard();
				String basePath = txtBasePath.getText();
				if(dragboard.hasFiles() && basePath != null) {
					List<File> files = dragboard.getFiles();
					String orgPath = basePath + "\\";
					LogUtil.record("basePath: " + orgPath);
					for(int i = 0; i < files.size(); i++) {
						// 检查路径是否是项目工程路径下
						String absolutePath = files.get(i).getAbsolutePath();
						if(absolutePath.indexOf(orgPath) >= 0) {
							// TODO 去除重复项
							dataList.add(absolutePath.replace(orgPath, ""));
							LogUtil.record("Add path success: " + absolutePath + " => " + absolutePath.replace(orgPath, ""));
						}else{
							LogUtil.record("Add path failed, not in basePath: " + absolutePath);
						}
					}
				}
			}
		});
		pathListView.setOnDragExited(new EventHandler<DragEvent>() {
			@Override
			public void handle(DragEvent event) {
				if(event.getDragboard().hasString()) {
					dataList.remove(event.getDragboard().getString());
				}
			}
		});

		pathListView.setItems(dataList);
	}

	private static final String PATTERN = "\\.[a-zA-Z]+";

	@FXML
	public void onBtnSaveAction() {
		TextField[] textFields = { txtVersionTag, txtBasePath, txtCachePath, txtProjectUrl, txtUploadUrl, txtDelelteUrl, txtCompareFolderName };
		String[] tipsList = { "versionTag", "项目路径", "备份路径", "versionUrl", "uploadUrl", "deleteUrl", "根目录名" };

		String errTips = null;
		do {
			for (int i = 0; i < textFields.length; i++) {
				if (textFields[i].getText() == null || textFields[i].getText().trim().isEmpty()) {
					errTips = tipsList[i] + "不能为空";
					break;
				}
			}
			if(errTips != null) {
				break;
			}

			if(!VersionPublishHelper.isDirExist(txtBasePath.getText().trim())){
				errTips = "项目路径不存在";
				break;
			}

			String[] prefixList = txtCompareFolderName.getText().trim().split(";");
			for(String str : prefixList){
				String folderPath  = txtBasePath.getText().trim() + "\\" + str;
				if(!VersionPublishHelper.isDirExist(folderPath)){
					errTips = "项目目录不存在:" + folderPath;
					break;
				}
			}

			String versionTag = txtVersionTag.getText().trim();
			if (versionTag.length() > 50) {
				errTips = "versionTag长度不能超过50";
				break;
			}
//			} else if (!"default".equals(versionTag) && !versionTag.startsWith("v")) {
//				errTips = "versionTag必须以v开头";
//				break;
//			}

			if(txtSuffix.getText() != null && !txtSuffix.getText().trim().isEmpty()){
				String excludeSuffix = txtSuffix.getText().trim();
				String[] suffixList = excludeSuffix.split(";");
				for(String str : suffixList){
					if(!str.matches(PATTERN)){
						errTips = "后缀名不合法:" + str;
						break;
					}
				}
			}

		}while(false);

		if(errTips != null) {
			new TipPanel(stage, errTips).show();
			return;
		}

		save();
	}

	private void save() {
		pathInfo.basePath = txtBasePath.getText();
		pathInfo.cachePath = txtCachePath.getText();
		pathInfo.versionTag = txtVersionTag.getText();
		pathInfo.ignoreFiles = txtIgnoreFiles.getText();
		pathInfo.excludeFiles = String.join(";", excludeFileList);
		pathInfo.excludeSuffix = txtSuffix.getText();
		pathInfo.includeFiles = String.join(";", includeFileList);
		pathInfo.compareFolderName = txtCompareFolderName.getText();
		pathInfo.scriptExt = txtScriptExt.getText();

		pathInfo.setProjectUrl(txtProjectUrl.getText());
		pathInfo.setUploadUrl(txtUploadUrl.getText());
		pathInfo.setDeleteUrl(txtDelelteUrl.getText());

		boolean ret = VersionPublishHelper.saveCustomConfig();

		if(ret){
			close();
		}
	}

	private String showChoosePathDialog(String initPath, String title) {
		DirectoryChooser dirChooser = new DirectoryChooser();
		if(initPath != null) {
			File dir = new File(initPath);
			dirChooser.setInitialDirectory((dir.exists()) ? dir : null);
		}

		dirChooser.setTitle(title);
		File configFile = dirChooser.showDialog(stage);
		return configFile != null ? configFile.getAbsolutePath() : "";
	}

	@FXML
	public void onBtnChoosePathAction() {
		txtBasePath.setText(showChoosePathDialog(txtBasePath.getText(), "选择项目的工程文件夹"));
	}

	@FXML
	public void onBtnChooseBackUpPathAction() {
		txtCachePath.setText(showChoosePathDialog(txtCachePath.getText(), "选择项目的备份文件夹"));
	}
}
