package ui.publish;

import config.VersionPublishType;
import javafx.fxml.FXML;
import javafx.stage.Window;

public class ZipGroupPublishPanel extends BaseGroupPublishPanel{

	public ZipGroupPublishPanel(Window owner) {
		super(owner, VersionPublishType.GROUP_VERSION_ZIP);
	}

	@FXML
	public void onBtnCompareEncriptAction(){
		super.onBtnCompareEncriptAction();
		btnPackage.setDisable(!_handler.hasDiff());
	}
}
