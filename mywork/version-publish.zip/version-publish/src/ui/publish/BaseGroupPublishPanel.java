package ui.publish;

import config.VersionPublishHelper;
import config.VersionPublishType;
import config.manifest.AssetData;
import config.manifest.ProjectManifestData;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Window;
import javafx.util.Callback;
import model.event.CommonEvent;
import model.event.CommonListener;
import model.event.OutputManager;
import model.handler.SFVersionHandler;
import model.handler.VersionHandlerBase;
import model.handler.ZipVersionHandler;
import ui.BasePanel;

public abstract class BaseGroupPublishPanel extends BasePanel{
	protected static final String FXML_PATH = "GroupPublishPane.fxml";
	protected static final String TITLE = "发布小版本";

	protected String publishType;
	protected VersionHandlerBase _handler;
	protected CommonListener listener;

	public BaseGroupPublishPanel(Window owner, String publishType) {
		super(owner, FXML_PATH, TITLE);

		this.publishType = publishType;
	}

	@FXML
	public TextField txtVersion;
	@FXML
	public TextField txtEngineVersion;
	@FXML
	public TextField txtNewGroupVer;
	@FXML
	public Label labelVersionCheck;
	@FXML
	public Label labelGroupVer;
	@FXML
	public Label labelInfo;
	@FXML
	public Label labelTitle;
	@FXML
	public ListView<AssetData> list;
	@FXML
	public TextArea txtOutput;
	@FXML
	public Button btnPackage;

	@Override
	protected boolean init() {
		switch(publishType) {
		case VersionPublishType.GROUP_VERSION_ZIP:
			_handler = new ZipVersionHandler();
			break;
		case VersionPublishType.GROUP_VERSION_SF:
			_handler = new SFVersionHandler();
			break;
		}

		VersionPublishHelper.envClear();
		boolean ret = _handler.initManifest(publishType);
		initListeners();
		initComponents();

		return ret;
	}

	private void initComponents() {
		ProjectManifestData manifestData = _handler.getManifestData();

		txtEngineVersion.setText(manifestData.engineVersion);
		txtVersion.setText(manifestData.tmpVersion);
		txtNewGroupVer.setText(manifestData.tmpGroupVersion);

		initListView();
	}

	protected void initListView(){
		updateFileList(list, _handler.getManifestData().getAssetDataList());
	}

	protected void updateFileList(ListView<AssetData> listView, ObservableList<AssetData> list){
		listView.setItems(list);
		listView.setCellFactory(new Callback<ListView<AssetData>, ListCell<AssetData>>() {
			@Override
			public ListCell<AssetData> call(ListView<AssetData> param) {
				return new ListCell<AssetData>(){
					@Override
					protected void updateItem(AssetData data, boolean empty) {
						super.updateItem(data, empty);
						if (data != null) {
							textProperty().bind(data.getKeyPty());
						} else {
							textProperty().unbind();
							setText("");
							setGraphic(null);
						}
					}
				};
			}
		});
	}

	private void initListeners() {
		listener = new CommonListener() {
			@Override
			public void handleEvent(CommonEvent event) {
				if(event.type == CommonEvent.EventType.INNER_MSG) {
					outputContent(event.msg);
				}
			}
		};
		OutputManager.getInstance().addListener(listener);
	}

	public void outputContent(String str){
		String org = txtOutput.getText();
		txtOutput.setText(org + str);
		txtOutput.end();
	}

	@FXML
	public void onBtnCompareEncriptAction(){
		//删除缓存文件
		_handler.clearWorkDir();
		//对比加密
		_handler.compareAndEncript(this);
	}

	@FXML
	public void onBtnPackageAction(){
		_handler.doPackage(this);
	}

	@FXML
	public void onBtnUploadAction(){
		_handler.doUpload(this);
//		String source = "E:\\cokutau-dev\\game\\ProjectC3_forVN\\assets";
//		String target = "E:\\cokutau-dev\\game\\ProjectC3_forVN\\assets.zip";
//		_handler.testPackage(source, target);
	}

	public void close() {
		super.close();
		OutputManager.getInstance().removeListener(listener);
	}
}
