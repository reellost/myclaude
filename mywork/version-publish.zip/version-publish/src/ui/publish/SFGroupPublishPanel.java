package ui.publish;

import config.VersionPublishHelper;
import config.VersionPublishType;
import config.manifest.AssetData;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.stage.Window;

public class SFGroupPublishPanel extends BaseGroupPublishPanel{

	public SFGroupPublishPanel(Window owner) {
		super(owner, VersionPublishType.GROUP_VERSION_SF);
	}

	protected void initListView(){
		labelTitle.setText("includeFiles:");
		String excludeFiles = VersionPublishHelper.getCustomConfigInfo().excludeFiles;
		if(excludeFiles != null && !excludeFiles.isEmpty()){
			String[] pathList = excludeFiles.split(";");
			ObservableList<AssetData> dataList = FXCollections.observableArrayList();
			for(String path : pathList){
				AssetData data = new AssetData();
				data.key = path;
				dataList.add(data);
			}
			updateFileList(list, dataList);
		}
	}

}
