package ui.publish;

import java.util.HashMap;
import java.util.Map;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.stage.Window;
import model.handler.SFVersionHandler;
import model.handler.VersionHandlerBase;
import model.handler.ZipVersionHandler;
import ui.BasePanel;
import ui.SurePanel;
import ui.TipPanel;
import util.HttpUtil;
import config.CustomConfigInfo;
import config.VersionPublishHelper;
import config.VersionPublishType;
import config.manifest.ProjectManifestData;

public class BigVersionPublishPanel extends BasePanel {
	protected static final String FXML_PATH = "BigVersionPublishPane.fxml";
	protected static final String TITLE = "发布大版本";

	protected String publishType;
	protected VersionHandlerBase _handler;

	public BigVersionPublishPanel(Window owner, String publishType) {
		super(owner, FXML_PATH, TITLE);

		this.publishType = publishType;
	}

	@FXML
	public TextField txtVersion;
	@FXML
	public TextField txtEngineVersion;
	@FXML
	public Label labelCurVersion;

	@Override
	protected boolean init() {
		// TODO Auto-generated method stub
		switch(publishType) {
		case VersionPublishType.BIG_VERSION_ZIP:
			_handler = new ZipVersionHandler();
			break;
		case VersionPublishType.BIG_VERSION_SF:
			_handler = new SFVersionHandler();
			break;
		}

		_handler.initManifest(publishType);
		initComponent();

		return true;
	}

	private void initComponent(){
		ProjectManifestData manifestData = _handler.getManifestData();
		labelCurVersion.setText("当前为：" + manifestData.version);
		txtVersion.setText(manifestData.tmpVersion);
		txtEngineVersion.setText(manifestData.engineVersion);
	}

	@FXML
	public void onBtnUpdateCacheAction(){
		new SurePanel(stage, ()->{
			TipPanel pane = new TipPanel(new Stage(), "更新缓存中...");
			pane.show();
			boolean ret = _handler.updateCacheFiles();
			if(ret) {
				pane.setText("更新缓存成功");
			}else {
				pane.setText("更新缓存失败，请检查目录是否正确");
			}

		},null).show();
	}

	@FXML
	public void onBtnUploadAction(){
		//TODO 检查版本号格式是否正确
		boolean ret = _handler.getManifestData().updateTmpVersion(txtVersion.getText());
		if(ret){
			new SurePanel(stage,()->{
				_handler.doUpload(this);
			},null).show();
		}else{
			new TipPanel(stage, "版本号格式不正确，请重新输入").show();
		}
	}

	@FXML
	public void onBtnDelConfigAction(){
		new SurePanel(stage,()->{
			Map<String, String> params = new HashMap<>();
			CustomConfigInfo customConfigInfo = VersionPublishHelper.getCustomConfigInfo();
			params.put("versionTag", customConfigInfo.versionTag);
			params.put("version", _handler.getManifestData().version);
			if (HttpUtil.postHttp(VersionPublishHelper.getCustomConfigInfo().getDeleteUrl(publishType), params)){
				new TipPanel(stage, "删除成功").show();
			}
		},null).show();
	}
}
