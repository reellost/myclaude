package ui;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.stage.Window;

public class TipPanel extends BasePanel {
	protected static final String FXML_PATH = "TipPane.fxml";
	protected static final String TITLE = "提示";

	@FXML
	Label label;

	private String message;

	public TipPanel(Window owner, String message){
		super(owner, FXML_PATH, TITLE);
		this.message = message;
	}

	@Override
	protected boolean init() {
		// TODO Auto-generated method stub
		label.setText(message);
		return true;
	}

	public void setText(String msg) {
		label.setText(msg);
	}
}
