package config;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.cokutau.common.utils.KuFileUtil;

import util.JsonFileUtil;
import util.LogUtil;

public class WorkspaceConfigInfo {
	public static final String LOG_PATH_SUFFIX = "\\log";
	public static final String RECORD_PATH_SUFFIX = "\\record";
	public static final String WORK_SPACE_SUFFIX = "\\workspace";
	public static final String ENCRIPT_SCRIPT_SUFFIX = "\\encripty.py";
	public static final String GZIP_ENCRIPT_SCRIPT_SUFFIX = "\\gzip_jsc.py";

	public static final String TMP_PATH_SUFFIX = "\\tmp";
	public static final String ZIP_PATH_SUFFIX = "\\zip";
	public static final String GZIP_PATH_SUFFIX = "\\gzip";
	public static final String ENCRIPT_PATH_SUFFIX = "\\encript";

	public static final String PROJECT_MANIFEST_NAME = "\\project.manifest";
	public static final String VERSION_MANIFEST_NAME = "\\version.manifest";

	public static final String TEMP_PROJECT_MANIFEST_NAME = "\\project.manifest.temp";

	public static final String ASSETS_ZIP_NAME = "\\assets.zip";

	public String workspacePath;

	public String logPath;
	public String tmpPath;
	public String zipPath;
	public String gzipPath;
	public String encriptPath;
	public String projectManifestPath;
	public String versionManifestPath;
	public String tmpProjectManifestPath;

	public String recordPath;

	public String encriptScriptPath;
	public String gzipEncriptScriptPath;

	public String scriptExt;

	public boolean gzip;

	public void updatePath(String cachePath) {
		logPath = cachePath + LOG_PATH_SUFFIX;
		recordPath = cachePath + RECORD_PATH_SUFFIX;
		workspacePath = cachePath + WORK_SPACE_SUFFIX;
		encriptScriptPath = cachePath + ENCRIPT_SCRIPT_SUFFIX;
		gzipEncriptScriptPath = cachePath + GZIP_ENCRIPT_SCRIPT_SUFFIX;

		tmpPath = workspacePath + TMP_PATH_SUFFIX;
		zipPath = workspacePath + ZIP_PATH_SUFFIX;
		gzipPath = workspacePath + GZIP_PATH_SUFFIX;
		encriptPath = workspacePath + ENCRIPT_PATH_SUFFIX;
		projectManifestPath = workspacePath + PROJECT_MANIFEST_NAME;
		versionManifestPath = workspacePath + VERSION_MANIFEST_NAME;
		tmpProjectManifestPath = workspacePath + TEMP_PROJECT_MANIFEST_NAME;

		LogUtil.record(String.format("cachePath: %s", cachePath));

		this.checkEncriptScript();
		this.checkCopyDefaluGZipEncriptScript();
	}

	private void checkEncriptScript() {
		File file = new File(encriptScriptPath);
		if(!file.exists()) {
			try {
				String str = JsonFileUtil.getStr(fxml.ViewPath.class.getResourceAsStream("encript.py"));
				KuFileUtil.writeStringToFile(file, str);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	private void checkCopyDefaluGZipEncriptScript() {
		File file = new File(gzipEncriptScriptPath);
		if(!file.exists()) {
			try {
				String str = JsonFileUtil.getStr(fxml.ViewPath.class.getResourceAsStream("gzip_jsc.py"));
				KuFileUtil.writeStringToFile(file, str);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public String getWorkspacePath() {
		return workspacePath;
	}

	public String getLogPath() {
		return logPath;
	}

	private static final SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd_HHmmss");

	public String getLogPath(String prefix) {
		return String.format("%s\\%s-%s.log", logPath, prefix, formatter.format(new Date()));
	}

	public String getRecordPath(){
		return recordPath;
	}

	public String getTmpPath() {
		return tmpPath;
	}

	public String getTmpPath(String type) {
		return tmpPath + "\\" + type;
	}

	public String getZipPath() {
		return zipPath;
	}

	public String getGZipPath() {
		return gzipPath;
	}

	public String getZipName() {
		return zipPath + ASSETS_ZIP_NAME;
	}

	public String getZipName(String type, String version) {
		return String.format("%s\\%s%s.zip", zipPath, type, version);
	}

	public String getEncriptPath() {
		return encriptPath;
	}

	public String getProjectManifestPath() {
		return projectManifestPath;
	}

	public String getVersionManifestPath() {
		return versionManifestPath;
	}

	public String getTmpProjectManifestPath() {
		return tmpProjectManifestPath;
	}
}
