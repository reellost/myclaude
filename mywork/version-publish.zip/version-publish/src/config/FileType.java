package config;

public class FileType {
	public static String SRC = "src";
	public static String RES = "res";
	public static String[] types = {SRC, RES};

	public static void update(String[] folderNameList) {
//		TODO: 此处存在潜规则，默认传入顺序为src,res，有时间再优化吧
		if(folderNameList.length >= 1){
			SRC = folderNameList[0];
		} else if (folderNameList.length >= 2) {
			RES = folderNameList[1];
		}
		types = folderNameList;
	}
}
