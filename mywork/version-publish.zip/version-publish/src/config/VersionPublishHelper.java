package config;

import java.io.File;
import java.io.IOException;

import org.apache.http.HttpEntity;

import com.cokutau.common.utils.KuFileUtil;

import model.ExecuteResult;
import util.HttpUtil;
import util.JsonFileUtil;
import util.LogUtil;

public class VersionPublishHelper {
	private static VersionPublishHelper _instance;
	public static VersionPublishHelper getInstance() {
		if(_instance == null) {
			_instance = new VersionPublishHelper();
		}
		return _instance;
	}

	private static final String CONFIG_FILE_NAME = "custom_config.json";

	private String configFilePath;

	private CustomConfigInfo customConfig;

	private WorkspaceConfigInfo workspaceConfig;

	private VersionPublishHelper() {
		customConfig = new CustomConfigInfo();
		workspaceConfig = new WorkspaceConfigInfo();
	}

	public boolean _init(String rootPath) {
		configFilePath = rootPath + CONFIG_FILE_NAME;
		CustomConfigInfo localConfig = (CustomConfigInfo)JsonFileUtil.readJson(configFilePath, CustomConfigInfo.class);
		if(localConfig != null) {
			customConfig = localConfig;
			workspaceConfig.updatePath(customConfig.cachePath);
		}

		return localConfig != null;
	}

	public boolean _saveCustomConfig() {
		JsonFileUtil.writJson(configFilePath, customConfig);
		workspaceConfig.updatePath(customConfig.cachePath);
		_envNew();

		return true;
	}

	public void _envNew() {
//		String name = ManagementFactory.getRuntimeMXBean().getName();
		_envClear();
		FileType.update(customConfig.getCompareFolderList());
		makeDirectory(workspaceConfig.logPath);
		LogUtil.setLogFile(workspaceConfig.getLogPath("record"));

		LogUtil.record(String.format("logPath:%s", workspaceConfig.logPath));
		LogUtil.record(String.format("workspacePath:%s", workspaceConfig.workspacePath));
	}

	public void _envClear() {
		remkdir(workspaceConfig.workspacePath);
	}

	public static void clearWorkDirectory() {
		WorkspaceConfigInfo workspaceConfig = getWorkspaceConfig();
		clearDirectory(workspaceConfig.tmpPath);
		clearDirectory(workspaceConfig.encriptPath);
		clearDirectory(workspaceConfig.zipPath);
	}

	public static boolean init(String rootPath) {
		return getInstance()._init(rootPath);
	}

	public static void envNew() {
		getInstance()._envNew();
	}

	public static void envClear() {
		getInstance()._envClear();
	}

	public static CustomConfigInfo getCustomConfigInfo(){
		return getInstance().customConfig;
	}

	public static WorkspaceConfigInfo getWorkspaceConfig() {
		return getInstance().workspaceConfig;
	}

	public static boolean isDirExist(String filePath){
		if(filePath == null || filePath.isEmpty()){
			return false;
		}

		File file = new File(filePath);
		return file.exists() && file.isDirectory();
	}

	public static ExecuteResult checkPathValid(){
		CustomConfigInfo customInfo = getCustomConfigInfo();
		ExecuteResult result = new ExecuteResult(true);
		do{
			// 1.检查是否存在项目路径
			if(!isDirExist(customInfo.basePath)){
				result.ret = false;
				result.msg = "项目路径不存在，请重新配置";
				break;
			}

			// 检查是否配置备份路径
			if(customInfo.cachePath == null || customInfo.cachePath.isEmpty()){
				result.ret = false;
				result.msg = "备份路径为空，请重新配置";
				break;
			}

		}while(false);

		return result;
	}

	public static boolean saveCustomConfig() {
		return getInstance()._saveCustomConfig();
	}

	public static boolean makeDirectory(String path) {
		boolean ret = false;
		File dir = new File(path);
		try {
			KuFileUtil.forceMkdir(dir);
			ret = true;
		} catch (IOException e) {
			// TODO Auto-generated catch block
//			System.err.print(e.getMessage());
			e.printStackTrace();
		}

		return ret;
	}

	public static void clearDirectory(String path){
		File file = new File(path);
		if(file.exists()){
			if(file.isFile()){
				file.delete();
			}else if(file.isDirectory()){
				File[] files = file.listFiles();
				for(File subfile : files){
					clearDirectory(subfile.getAbsolutePath());
				}
				file.delete();
			}
		}
	}

	public static boolean remkdir(String path){
		File file = new File(path);
		clearDirectory(path);
		if(!file.exists()){
			return file.mkdir();
		}

		return true;
	}

	public static boolean isIgnoreFile(File file) {
		return getCustomConfigInfo().isInIgnoreFiles(file.getName());
	}

	public static boolean isExcludeFile(File file){
		return getCustomConfigInfo().isInExcludeSuffix(file.getName());
	}

	public static void saveLogFile(HttpEntity entity, String filename) {
		HttpUtil.saveHttpEntity(entity, getWorkspaceConfig().getLogPath(filename));
	}
}
