package config.manifest;

import javafx.beans.property.Property;
import javafx.beans.property.SimpleStringProperty;

public class AssetData {
	public String md5;
	public boolean compressed; //
	public long size;
	public String path; // 存放下载路径，示例：src.cocos.cocos2d.OpenglConstants.lua，上传后会加上版本信息
	public int tag; //
	public String key; // 形如 src/cocos/cocos2d/OpenglConstants.lua
	public String version;
	public String type; // 类型 src/res
	public String fbl; // 分辨率，对于图片类会有
	public boolean changed;

	public void updateKey(String key) {
		this.key = key;
	}

	public Property<String> getKeyPty(){
		Property<String> fileName = new SimpleStringProperty();
		fileName.setValue(this.key);
		return fileName;
	}

	public void updateInfo(String path, long size, String md5, int tag, boolean compressed) {
		this.path = path;
		this.size = size;
		this.md5 = md5;
		this.tag = tag;
		this.compressed = compressed;
		this.changed = true;
	}

	/**
	 *
	 * @param fileId  示例 src.BattleDemoScene.lua
	 * @param size
	 * @param md5
	 */
	public void updateInfoSF(String fileId, long size, String md5, String fbl) {
		updateInfo(fileId, size, md5, 0, false);

		this.fbl = fbl;
	}

	/**
	 *
	 * @param filePath 本地完整路径，用于获取存放地址
	 * @param size
	 * @param md5
	 * @param tag
	 */
	public void updateInfoZip(String filePath, long size, String md5, int tag) {
		updateInfo(filePath, size, md5, tag, true);
	}
}
