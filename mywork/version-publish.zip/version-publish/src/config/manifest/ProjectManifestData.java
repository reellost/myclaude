package config.manifest;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

import javax.imageio.ImageIO;

import config.FileType;
import config.VersionPublishHelper;
import config.VersionPublishType;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.FileResult;
import util.CompareUtil;

public class ProjectManifestData{
	public boolean isTempData = false;
	public String version;
	public String groupVersion;
	public String engineVersion;

	public HashMap<String, AssetData> assets;
	public HashMap<String, AssetData> tmpAssets;
	public String tmpGroupVersion;
	public String tmpVersion;

	public static ProjectManifestData getInitProjectManifestData(){
		ProjectManifestData data = new ProjectManifestData();
		data.version = "1.0.0";
		data.engineVersion = "3.16";
		data.groupVersion = "1.0.0.0";
		data.assets = new HashMap<>();
		data.isTempData = true;
		return data;
	}

	/**
	 *
	 * @param pdata
	 * @return
	 */
	public static ProjectManifestData copy(ProjectManifestData pdata){
		ProjectManifestData data = new ProjectManifestData();
		data.version = pdata.version;
		data.groupVersion = pdata.groupVersion;
		data.engineVersion = pdata.engineVersion;
		data.assets = pdata.assets;
		return data;
	}

	/**
     * 根据类型生成相关的manifest信息
     *     大版本类型：大版本版本号加一 清空小版本
     *     小版本类型：根据小版本的数量 提小版本号
	 * @param type
	 */
	public void initProjectInfo(String type){
		switch (type) {
		case VersionPublishType.BIG_VERSION_ZIP:
		case VersionPublishType.BIG_VERSION_SF:
			//大版本版本号加一 清空小版本
			tmpVersion = getNewBigVer();
			tmpGroupVersion = tmpVersion + ".0";
			assets = new HashMap<>();
			break;
		case VersionPublishType.GROUP_VERSION_ZIP:
		case VersionPublishType.GROUP_VERSION_SF:
			//根据小版本的数量 提小版本号
			tmpVersion = version;
			tmpGroupVersion = getNewGroupVer();
			break;
		default:
			break;
		}

		tmpAssets = new HashMap<>();

		for(Map.Entry<String, AssetData> entry : assets.entrySet()) {
			AssetData asset = entry.getValue();
			asset.updateKey(entry.getKey());
		}
	}

	private static final String PATTERN = "^\\d+(\\.\\d+){2,}$"; // 1.0.0

	public boolean updateTmpVersion(String version){
		boolean match = Pattern.matches(PATTERN, version);
		if(match){
			tmpVersion = version;
			tmpGroupVersion = version + ".0";
		}

		return match;
	}

	public ObservableList<AssetData> getAssetDataList(){
		ObservableList<AssetData> list = FXCollections.observableArrayList();
		for(Map.Entry<String, AssetData> entry : assets.entrySet()) {
			AssetData data = entry.getValue();
			list.add(data);
		}
		return list;
	}

	public HashMap<String, ObservableList<AssetData>> getAssetDataListMap(){
		HashMap<String, ObservableList<AssetData>> map = new HashMap<>();
		ObservableList<AssetData> srcList = FXCollections.observableArrayList();
		ObservableList<AssetData> resList = FXCollections.observableArrayList();
		for(Map.Entry<String, AssetData> entry : assets.entrySet()) {
			AssetData data = entry.getValue();
			if(entry.getKey().matches("^src.*?\\.luac?$")) {
				srcList.add(data);
			}else {
				resList.add(data);
			}
		}
		srcList.sort(new Comparator<AssetData>() {
			@Override
			public int compare(AssetData o1, AssetData o2) {
				return o1.key.compareTo(o2.key);
			}
		});
		map.put(FileType.SRC, srcList);
		map.put(FileType.RES, resList);

		return map;
	}

	public void updateTmpAssetData(FileResult fileResult) {
		String fileId = fileResult.getFileId();
		String key = fileResult.getRelativePath().replace("\\", "/");
		AssetData data = tmpAssets.get(key);
		if(data == null) {
			data = new AssetData();
			data.updateKey(key);
			tmpAssets.put(fileId, data);
		}

		File file = new File(fileResult.getEncriptPath());
		long size = file.length();
		String md5 = CompareUtil.getMD5Checksum(file);

		String fbl = null;
		BufferedImage image;
		try {
			image = ImageIO.read(file);
			if(image != null){
				fbl = String.format("%d*%d", image.getWidth(), image.getHeight());
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.err.print(e.getMessage());
		}

		data.updateInfoSF(fileId, size, md5, fbl);
	}

	public void updateTmpAssetData(String type, String version){
		String filepath = VersionPublishHelper.getWorkspaceConfig().getZipName(type, version);
		File newzip = new File(filepath);

		AssetData data = tmpAssets.get(newzip.getName());
		if(data == null){
			data = new AssetData();
			tmpAssets.put(newzip.getName(), data);
		}

		int tag = tmpAssets.size();
		long size = newzip.length();
		String md5 = CompareUtil.getMD5Checksum(newzip);
		data.updateInfoZip(filepath, size, md5, tag);
	}

	/**
     * 获得下个版本的版本号
     */
	private String getNewGroupVer(){
		return groupVersion == null ? (tmpVersion + ".0") : getNewVersion(groupVersion);
	}

	/**
     * 提升大版本号最后一位 并返回
     */
	private String getNewBigVer(){
		String last = version;
		String newVer = getNewVersion(last);
		return newVer;
	}

	/**
     * 传入版本号 提升该版本号最后一位
     */
	private String getNewVersion(String ver){
		String[] vers = ver.split("\\.");
		int i = Integer.valueOf(vers[vers.length-1]).intValue() + 1;
		vers[vers.length-1] = String.valueOf(i);
		return String.join(".", vers);
	}
}
