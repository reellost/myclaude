package config;

import java.util.Arrays;

public class VersionPublishType {
	public static final String BIG_VERSION_ZIP = "big_version_zip";
	public static final String BIG_VERSION_SF = "big_version_single_file";
	public static final String GROUP_VERSION_ZIP = "group_version_zip";
	public static final String GROUP_VERSION_SF = "group_version_single_file";
	
	private static final String[] GROUP_TYPES = {GROUP_VERSION_ZIP, GROUP_VERSION_SF};
	
	private static final String[] SF_TYPES = {BIG_VERSION_SF, GROUP_VERSION_SF};
	
	public static boolean isSFType(String type) {
		return Arrays.asList(SF_TYPES).contains(type);
	}
	
	public static boolean isGroupType(String type) {
		return Arrays.asList(GROUP_TYPES).contains(type);
	}
}
