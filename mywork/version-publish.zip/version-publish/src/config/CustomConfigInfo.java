package config;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CustomConfigInfo {
	public String basePath;
	public String cachePath;
	public String versionTag;
	public String projectUrl;
	public String projectUrl4f;
	public String uploadUrl;
	public String uploadUrl4sf;
	public String deleteUrl;
	public String deleteUrl4sf;
	public String ignoreFiles;		// 全局忽略对比的文件
	public String includeFiles;		// 指定热更必须包含的文件(夹)，对应单文件模式剔除的文件(夹)，高优先级
	public String excludeFiles;		// 热更剔除的文件夹(夹)，对应单文件模式包含的文件(夹)，低优先级
	public String excludeSuffix;	// 和excludeFiles同时使用，指定热更需要剔除的文件后缀，对应单文件模式针对的后缀

	public String[] excludeFileList;
	public String[] includeFileList;

	public String compareFolderName;

	public String scriptExt;

	public boolean gzip;

	public String getCachePath() {
		return cachePath;
	}

	public String getCachePath(String fileType) {
		return cachePath + "\\" + fileType;
	}

	public String getBasePath(String fileType) {
		return basePath + "\\" + fileType;
	}
	
	public String getProjectUrl(String publishType) {
		if(VersionPublishType.isSFType(publishType)) {
			return projectUrl4f;
		}

		return projectUrl;
	}

	public String getUploadUrl(String publishType) {
		if(VersionPublishType.isSFType(publishType)) {
			return uploadUrl4sf;
		}

		return uploadUrl;
	}

	public String getDeleteUrl(String publishType) {
		if(VersionPublishType.isSFType(publishType)) {
			return deleteUrl4sf;
		}

		return deleteUrl;
	}

	private final Pattern pattern = Pattern.compile("v\\d+(\\.\\d+)+");

//	public void setVersionUrl(String url) {
//		versionUrl = url;
//		/**
//		 *
//		 * http://res.dev-pjc3d.cokutau.cn:97//version.manifest  --->http://res.dev-pjc3d.cokutau.cn:97/vsf/version.manifest
//		 * http://res.dev-pjc3d.cokutau.cn:97/v1.0.0/version.manifest	--->http://res.dev-pjc3d.cokutau.cn:97/vsfv1.0.0/version.manifest
//		 */
////		Matcher m = pattern.matcher(url);
////        if(m.find()){
////            versionUrl4sf = String.format("%svsf%s", url.substring(0, m.start()), url.substring(m.start()));
////        }else{
////            int index = url.lastIndexOf("/");
////            versionUrl4sf = String.format("%s/vsf%s", url.substring(0, index), url.substring(index));
////        }
////
//        int index = url.lastIndexOf("/", url.lastIndexOf("/") - 1);
//        versionUrl4sf = String.format("%svsf%s", url.substring(0, index + 1), url.substring(index +1));
//	}
	
	public void setProjectUrl(String url) {
		projectUrl = url;
        int index = url.lastIndexOf("/", url.lastIndexOf("/") - 1);
        projectUrl4f = String.format("%svsf%s", url.substring(0, index + 1), url.substring(index +1));
	}

	public void setUploadUrl(String url) {
		uploadUrl = url;
		uploadUrl4sf = url + "4sf";
	}

	public void setDeleteUrl(String url) {
		deleteUrl = url;
		deleteUrl4sf = url + "4sf";
	}

	public boolean isInIgnoreFiles(String fileName){
		if(ignoreFiles != null){
			return ignoreFiles.indexOf(fileName) >= 0;
		}

		return false;
	}

	public boolean isInExcludeSuffix(String fileName){
		if(excludeSuffix != null){
			String suffix = fileName.substring(fileName.lastIndexOf(".") + 1);
			return excludeSuffix.indexOf(suffix) >= 0;
		}

		return true;
	}

	public List<String> getExcludeFileList(){
		return parseStrToList(excludeFiles, null);
	}

	public List<String> getExcludeFileList(String type){
		return parseStrToList(excludeFiles, type);
	}

	public List<String> getIncludeFileList(){
		return parseStrToList(includeFiles, null);
	}

	public List<String> getIncludeFileList(String type){
		return parseStrToList(includeFiles, type);
	}
	
	public String[] getExcludeFileNameList(){
		if(excludeFiles == null) {
			String[] result = {FileType.SRC, FileType.RES};
			return result;
		}
		return excludeFiles.split(";");
	}

	private List<String> parseStrToList(String fileStr, String type){
		List<String> list = new ArrayList<String>();
		if(fileStr != null && !fileStr.isEmpty()){
			String[] files = fileStr.split(";");
			for(String file : files){
				if(type == null || file.startsWith(type)){
					list.add(basePath + "\\" + file);
				}
			}
		}

		return list;
	}

	public String[] getCompareFolderList() {
		if(compareFolderName == null || compareFolderName.isEmpty()) {
			String[] result = {FileType.SRC, FileType.RES};
			return result;
		}
		return compareFolderName.split(";");
	}
}
